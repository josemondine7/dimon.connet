'use strict';
// Capa de datos de Dimon Connet (v1: archivos JSON en ./data).
// Diseñada para swapear a MongoDB después: cambiá solo este archivo por uno
// que implemente las mismas funciones contra una URI mongodb+srv://.

const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');
const FILES = {
  users: path.join(DATA_DIR, 'users.json'),
  posts: path.join(DATA_DIR, 'posts.json'),
  deals: path.join(DATA_DIR, 'deals.json'),
  sessions: path.join(DATA_DIR, 'sessions.json')
};

function ensureDir() {
  if (!fs.existsSync(DATA_DIR)) { fs.mkdirSync(DATA_DIR, { recursive: true }); }
}
function read(file, fallback) {
  try {
    if (!fs.existsSync(file)) { return fallback; }
    const raw = fs.readFileSync(file, 'utf8');
    return raw ? JSON.parse(raw) : fallback;
  } catch (e) { return fallback; }
}
function write(file, data) {
  ensureDir();
  fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8');
}
function nextId(list) {
  let max = 0;
  for (let i = 0; i < list.length; i++) { if (list[i].id > max) { max = list[i].id; } }
  return max + 1;
}

const DB = {
  // ----- Usuarios -----
  findUser: function (usernameOrEmail) {
    const users = read(FILES.users, []);
    const key = String(usernameOrEmail || '').toLowerCase();
    for (let i = 0; i < users.length; i++) {
      if (users[i].username.toLowerCase() === key || (users[i].email && users[i].email.toLowerCase() === key)) {
        return users[i];
      }
    }
    return null;
  },
  findUserById: function (id) {
    const users = read(FILES.users, []);
    for (let i = 0; i < users.length; i++) { if (users[i].id === id) { return users[i]; } }
    return null;
  },
  createUser: function (user) {
    const users = read(FILES.users, []);
    user.id = nextId(users);
    user.createdAt = new Date().toISOString();
    users.push(user);
    write(FILES.users, users);
    return user;
  },
  listUsers: function () { return read(FILES.users, []); },

  // ----- Publicaciones -----
  listPosts: function (filter) {
    filter = filter || {};
    let posts = read(FILES.posts, []);
    if (filter.category) { posts = posts.filter(function (p) { return p.category === filter.category; }); }
    if (filter.country) { posts = posts.filter(function (p) { return p.country === filter.country; }); }
    return posts;
  },
  createPost: function (post) {
    const posts = read(FILES.posts, []);
    post.id = nextId(posts);
    post.createdAt = new Date().toISOString();
    posts.push(post);
    write(FILES.posts, posts);
    return post;
  },

  // ----- Tratos -----
  listDeals: function () { return read(FILES.deals, []); },
  createDeal: function (deal) {
    const deals = read(FILES.deals, []);
    deal.id = nextId(deals);
    deal.createdAt = new Date().toISOString();
    deals.push(deal);
    write(FILES.deals, deals);
    return deal;
  },

  // ----- Sesiones (admin / auditoría) -----
  listSessions: function () { return read(FILES.sessions, []); },
  addSession: function (session) {
    const sessions = read(FILES.sessions, []);
    session.id = nextId(sessions);
    session.at = new Date().toISOString();
    sessions.push(session);
    write(FILES.sessions, sessions);
    return session;
  }
};

module.exports = DB;

# Política de Privacidad — Dimon Connet
**Versión 1.0 — Octubre 2026**
**Responsable:** José Mondine (creador de Dimon Connet)
**Contacto:** dimon.connet@gmail.com

---

## 1. Qué datos guardamos y por qué
Para que la plataforma funcione, guardamos solo los datos necesarios:
- **Cuenta:** nombre de usuario, correo electrónico y contraseña (guardada encriptada, nunca en texto plano).
- **Perfil:** foto (opcional), ciudad, país, descripción y servicios que ofrecés o necesitás.
- **Publicaciones:** el texto y la categoría de lo que publicás.
- **Tratos:** registro de los acuerdos que confirmás dentro de la plataforma.
- **Sesiones:** registro de ingresos para tu seguridad (fecha, hora y tipo de dispositivo).

## 2. Lo que NO hacemos con tus datos
- No vendemos ni compartimos tus datos con terceros.
- No mostramos tu número de teléfono, correo ni contraseña a otros usuarios. Para contactarte, los demás usan el chat interno de la plataforma.
- No usamos tus datos para publicidad dirigida.

## 3. Cuánto tiempo guardamos tus datos
- Mientras tu cuenta esté activa, guardamos solo lo necesario para que funcione.
- Si pasás **6 meses sin entrar**, te avisamos. Si seguís sin conectarte, la cuenta se cierra y **toda tu información se elimina**.
- Cuando eliminás tu cuenta, tus datos se borran de nuestros sistemas. **No guardamos copias de respaldo permanentes**: tus datos son tuyos mientras participás; cuando te vas, se van con vos.

## 4. Tus derechos
Podés en cualquier momento:
- Ver y modificar tus datos personales (desde tu perfil).
- Descargar tu información (solicitándola por correo).
- Eliminar tu cuenta definitivamente.
- Pedir que dejemos de usar tus datos.

## 5. Medios de pago
Dimon Connet **no maneja tu dinero**. Los pagos se hacen a través de PayPal, Mercado Pago o Stripe. Esas plataformas tienen sus propias políticas de privacidad y guardan los datos de tu tarjeta — nosotros no tenemos acceso a ellos.

## 6. Seguridad
- Las contraseñas se guardan encriptadas (bcrypt).
- Las sesiones se protegen con tokens JWT.
- Las zonas privadas (Dimon General, actas) solo se acceden con contraseña de administrador.
- Si detectás un uso extraño de tu cuenta, contactanos a dimon.connet@gmail.com.

## 7. Menores de edad
La plataforma es para mayores de 18 años. Si sos menor, necesitás autorización de un adulto responsable.

## 8. Cambios en esta política
Si cambiamos algo, te lo avisamos dentro de la plataforma y por correo. El uso continuado implica aceptación de la versión vigente.

---
*Esta política es una versión inicial en lenguaje sencillo. Para validez legal formal, recomendamos que un abogado o escribano la revise.*

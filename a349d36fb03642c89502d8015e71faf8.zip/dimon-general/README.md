# Dimon General (zona privada del dueño)

Decisión de arquitectura: Dimon General está implementado como una pantalla
del SPA (`#screen-dimon-general`) en `public/index.html`, y no como un sitio
separado. Esto permite que todo el proyecto funcione con un solo `npm start`
en Render, sin sesiones ni cookies adicionales.

## Acceso (oculto para usuarios comunes)

No aparece en el menú lateral. Se accede de tres formas:

1. Tocando 5 veces seguidas el logo en la pantalla de Login.
2. Visitando la ruta `/admin` (el servidor redirige a `/#admin`).
3. Tocando el punto diminuto al pie de "Información del creador".

## Seguridad

- La contraseña se valida contra el servidor: `POST /api/creator-login`.
- La contraseña real solo existe en la variable de entorno `CREATOR_PASSWORD`.
- Si no está definida, el default es `dimon2026` y la UI fuerza cambiarla.
- Dentro de esta zona NO se incluyen números de cédula ni documentos sensibles.
  El documento de sucesión, si se incluye, va solo acá y sin datos personales.

## Contenido

- Analítica de uso (estadísticas simuladas, filtros día/semana/mes).
- Repositorio / código (lista de archivos del proyecto).
- Tareas y mejoras (lista editable, guardada en localStorage).
- Historial de versiones.
- Ingresos (cuotas comercios US$ 45, comisiones 15%, destacados).
- Gestión (categorías, textos legales, reportes).
- Seguridad (sesiones simuladas, cerrar otras sesiones).

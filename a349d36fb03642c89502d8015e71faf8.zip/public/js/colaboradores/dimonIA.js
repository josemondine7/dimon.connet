'use strict';
// Dimon IA — asistente de voz/texto. 138 colaboradores = 11 áreas conceptuales.
// Llama a /api/dimon-chat (proxy Groq); si no hay clave, usa respuestas simuladas.
(function () {
  // 11 áreas de especialistas (roles conceptuales, NO archivos de código).
  var AREAS = [
    { name: 'Desarrollo y Tecnología', keywords: ['app', 'código', 'programar', 'web', 'api', 'error'] },
    { name: 'Diseño y Creatividad', keywords: ['diseño', 'logo', 'imagen', 'marca', 'creativo'] },
    { name: 'Redacción y Traducción', keywords: ['texto', 'redactar', 'traducir', 'idioma', 'escribir'] },
    { name: 'Ventas y Marketing', keywords: ['vender', 'marketing', 'clientes', 'publicidad'] },
    { name: 'Administración y Apoyo', keywords: ['administrar', 'organizar', 'agenda', 'gestión'] },
    { name: 'Finanzas y Contabilidad', keywords: ['dinero', 'impuestos', 'contabilidad', 'precio', 'cobrar'] },
    { name: 'Legal', keywords: ['legal', 'contrato', 'ley', 'términos', 'norma'] },
    { name: 'Ingeniería y Arquitectura', keywords: ['obra', 'construcción', 'plano', 'ingeniero'] },
    { name: 'Ciencia de Datos', keywords: ['datos', 'estadística', 'gráfico', 'analítica'] },
    { name: 'Atención al Cliente', keywords: ['ayuda', 'consulta', 'problema', 'reclamo'] },
    { name: 'RRHH y Formación', keywords: ['curso', 'clase', 'formación', 'personal', 'equipo'] }
  ];

  var chatHistory = [];
  var orbState = 'idle';

  function fees() {
    var f = (window.App && window.App.state && window.App.state.config && window.App.state.config.fees) || { hirer: 15, worker: 15, total: 30 };
    return f;
  }

  function simulatedReply(text) {
    var t = (text || '').toLowerCase();
    var f = fees();
    if (t.indexOf('publicar') >= 0 || t.indexOf('publicá') >= 0 || t.indexOf('subir') >= 0) {
      return 'Para publicar: tocá el + en la barra inferior, elegí foto/video, escribí título y descripción, elegí si ofrecés o necesitás, la categoría y la duración (14 días en el muro o 365 en el perfil). Recordá: no se permiten teléfonos, correos ni enlaces.';
    }
    if (t.indexOf('destac') >= 0) {
      return 'Hay 3 opciones de destacado: aparecer primero 24h (US$2.99), hasta 10x al día (US$1.99), o el combinado (US$4.49). Se paga por PayPal, Mercado Pago o Stripe según tu país.';
    }
    if (t.indexOf('comisión') >= 0 || t.indexOf('cobran') >= 0 || t.indexOf('cuánto cobran') >= 0 || t.indexOf('porcentaje') >= 0) {
      return 'La comisión es del ' + f.hirer + '% para quien recibe/solicita el servicio y ' + f.worker + '% para quien lo brinda/trabaja: ' + f.total + '% total para la plataforma. Solo se cobra cuando el trato se concreta y ambas partes confirman. Si no hay trato, no hay cobro.';
    }
    if (t.indexOf('país') >= 0 || t.indexOf('paises') >= 0 || t.indexOf('idioma') >= 0) {
      return 'Estamos en más de 60 países. Tocá la bandera en la bienvenida o el menú de idioma para cambiar de país e idioma. La UI está en español, portugués, inglés y francés.';
    }
    if (t.indexOf('gratis') >= 0 || t.indexOf('cuesta') >= 0) {
      return 'Crear cuenta, navegar, publicar, crear proyectos y chatear es siempre gratis. Solo se cobra la comisión cuando hay un trato concreto (' + f.hirer + '% + ' + f.worker + '%), los destacados opcionales y la cuota de comercios (US$45/mes).';
    }
    if (t.indexOf('hola') >= 0 || t.indexOf('buen') >= 0) {
      return '¡Hola! Soy Dimon IA. Puedo ayudarte a publicar un servicio, explicar los planes de destacado, las comisiones o los países disponibles. ¿Qué necesitás?';
    }
    // Derivar a área conceptual
    var area = null;
    for (var i = 0; i < AREAS.length; i++) {
      for (var j = 0; j < AREAS[i].keywords.length; j++) {
        if (t.indexOf(AREAS[i].keywords[j]) >= 0) { area = AREAS[i].name; break; }
      }
      if (area) { break; }
    }
    if (area) {
      return 'Te derivo al especialista de ' + area + '. Mientras tanto: recordá que en Dimon Connet todo acuerdo se documenta en el Acta de trato (qué, cuánto, cuándo y fecha), y la comisión es ' + f.hirer + '% + ' + f.worker + '% solo al concretarse.';
    }
    return 'Buena pregunta. Estoy para ayudarte con publicar, destacar, comisiones (' + f.hirer + '% + ' + f.worker + '%), países y cómo funciona la plataforma. ¿Querés que te explique alguno en detalle?';
  }

  function addBubble(text, who) {
    var chat = document.getElementById('dimon-chat');
    if (!chat) { return; }
    var div = document.createElement('div');
    div.className = 'chat-bubble ' + who;
    div.textContent = text;
    chat.appendChild(div);
    chat.scrollTop = chat.scrollHeight;
  }

  function setOrb(state) {
    orbState = state;
    var orb = document.getElementById('dimon-orb');
    if (!orb) { return; }
    orb.className = 'dimon-orb state-' + state;
  }

  function speak(text) {
    if (!('speechSynthesis' in window)) { return; }
    try {
      window.speechSynthesis.cancel();
      var u = new SpeechSynthesisUtterance(text);
      var voiceSel = document.getElementById('dimon-voice');
      var v = voiceSel ? voiceSel.value : 'adult';
      u.pitch = v === 'young' ? 1.3 : (v === 'senior' ? 0.7 : 1.0);
      u.rate = 1.0;
      u.lang = (window.App && window.App.state && window.App.state.lang === 'pt') ? 'pt-BR' : (window.App.state.lang === 'fr' ? 'fr-FR' : 'es-ES');
      setOrb('speaking');
      u.onend = function () { setOrb('idle'); };
      window.speechSynthesis.speak(u);
    } catch (e) { setOrb('idle'); }
  }

  async function sendUser(text) {
    if (!text || !text.trim()) { return; }
    addBubble(text, 'user');
    chatHistory.push({ role: 'user', content: text });
    setOrb('processing');
    var reply = null;
    if (window.Api && window.Api.dimonChat) {
      try {
        var r = await window.Api.dimonChat(chatHistory);
        if (r && r.simulated === false && r.reply) { reply = r.reply; }
      } catch (e) { reply = null; }
    }
    if (!reply) { reply = simulatedReply(text); }
    chatHistory.push({ role: 'assistant', content: reply });
    setOrb('idle');
    addBubble(reply, 'bot');
    speak(reply);
  }

  window.DimonIA = {
    AREAS: AREAS,
    init: function () {
      var orb = document.getElementById('dimon-orb');
      var taps = 0, timer = null;
      if (orb) {
        orb.addEventListener('click', function () {
          taps++;
          clearTimeout(timer);
          timer = setTimeout(function () {
            if (taps >= 2) {
              addBubble('Modo conversación activado. Hablame y te respondo.', 'bot');
              speak('Modo conversación activado.');
            } else {
              // 1 toque: escuchar (SpeechRecognition si existe, sino pedir texto)
              var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
              if (SR) {
                try {
                  var rec = new SR();
                  setOrb('listening');
                  rec.lang = 'es-ES';
                  rec.onresult = function (e) { var txt = e.results[0][0].transcript; setOrb('idle'); sendUser(txt); };
                  rec.onerror = function () { setOrb('idle'); window.App.showToast('Usá el campo de texto'); };
                  rec.start();
                  return;
                } catch (e) { setOrb('idle'); }
              }
              var inp = document.getElementById('dimon-text-input');
              if (inp) { inp.focus(); }
            }
            taps = 0;
          }, 350);
        });
      }
      var sendBtn = document.getElementById('btn-dimon-send');
      if (sendBtn) { sendBtn.addEventListener('click', function () {
        var inp = document.getElementById('dimon-text-input');
        if (inp) { sendUser(inp.value); inp.value = ''; }
      }); }
      var inp = document.getElementById('dimon-text-input');
      if (inp) { inp.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') { sendUser(inp.value); inp.value = ''; }
      }); }
      var done = document.getElementById('btn-dimon-done');
      if (done) { done.addEventListener('click', function () {
        if ('speechSynthesis' in window) { try { window.speechSynthesis.cancel(); } catch (e) {} }
        window.App.goBack();
      }); }
      // Saludo al entrar a la pantalla
      var observer = new MutationObserver(function () {
        var screen = document.getElementById('screen-dimon');
        if (screen && screen.classList.contains('active') && chatHistory.length === 0) {
          var f = fees();
          var hi = '¡Hola! Soy Dimon IA. Te ayudo a publicar, destacar y entender las comisiones (' + f.hirer + '% + ' + f.worker + '%). ¿Qué necesitás?';
          addBubble(hi, 'bot');
        }
      });
      observer.observe(document.body, { attributes: true, subtree: true, attributeFilter: ['class'] });
    }
  };
})();

'use strict';
// Dimon Connet — núcleo de la aplicación (estado global, navegación, utilidades).
(function () {
  var App = {
    state: {
      lang: 'es',
      country: 'UY',
      filter: 'world',
      categoryFilter: null,
      history: ['screen-welcome'],
      currentScreen: 'screen-welcome',
      config: { paypalMode: 'live', payments: {}, groqEnabled: false, fees: { hirer: 10, worker: 10, total: 20 } }
    },
    currentUser: null,
    // ---------- Navegación ----------
    switchScreen: function (id, push) {
      var target = document.getElementById(id);
      if (!target) { console.warn('switchScreen: pantalla inexistente', id); return; }
      var prev = document.querySelector('.screen.active');
      if (prev) { prev.classList.remove('active'); }
      target.classList.add('active');
      App.state.currentScreen = id;
      if (push !== false) { App.state.history.push(id); }
      App.closeDrawer();
      window.scrollTo(0, 0);
      var sc = target.querySelector('.scroll, .feed-container, .auth-body');
      if (sc) { sc.scrollTop = 0; }
    },
    goBack: function () {
      if (App.state.history.length > 1) {
        App.state.history.pop();
        var prev = App.state.history[App.state.history.length - 1];
        App.switchScreen(prev, false);
      } else {
        App.switchScreen('screen-feed', false);
      }
    },
    // ---------- Internacionalización ----------
    t: function (key) {
      var dict = window.Translations && window.Translations[App.state.lang]
        ? window.Translations[App.state.lang]
        : (window.Translations ? window.Translations.en : {});
      var parts = key.split('.');
      var cur = dict;
      for (var i = 0; i < parts.length; i++) {
        if (cur && typeof cur === 'object' && parts[i] in cur) { cur = cur[parts[i]]; }
        else {
          var en = window.Translations && window.Translations.en;
          var c2 = en;
          for (var j = 0; j < parts.length; j++) {
            if (c2 && typeof c2 === 'object' && parts[j] in c2) { c2 = c2[parts[j]]; } else { return key; }
          }
          return typeof c2 === 'string' ? c2 : key;
        }
      }
      return typeof cur === 'string' ? cur : key;
    },
    formatFees: function (str) {
      if (typeof str !== 'string') { return str; }
      var f = (App.state && App.state.config && App.state.config.fees) || { hirer: 10, worker: 10, total: 20 };
      return str.replace(/\{feeHirer\}/g, f.hirer).replace(/\{feeWorker\}/g, f.worker).replace(/\{feeTotal\}/g, f.total);
    },
    applyTranslations: function () {
      var els = document.querySelectorAll('[data-i18n]');
      for (var i = 0; i < els.length; i++) {
        els[i].textContent = App.formatFees(App.t(els[i].getAttribute('data-i18n')));
      }
      var phs = document.querySelectorAll('[data-i18n-placeholder]');
      for (var k = 0; k < phs.length; k++) {
        phs[k].setAttribute('placeholder', App.formatFees(App.t(phs[k].getAttribute('data-i18n-placeholder'))));
      }
      document.title = App.t('app.title') + ' — ' + App.t('app.subtitle');
    },
    setLang: function (code, countryCode) {
      App.state.lang = code;
      if (countryCode) { App.state.country = countryCode; }
      try { localStorage.setItem('dimon_lang', code); localStorage.setItem('dimon_country', App.state.country); } catch (e) {}
      App.applyTranslations();
      App.updateFlagBar();
    },
    updateFlagBar: function () {
      var c = window.Countries && window.Countries.byCode ? window.Countries.byCode(App.state.country) : null;
      if (!c) { return; }
      var f = document.getElementById('flag-current');
      var n = document.getElementById('country-name');
      if (f) { f.textContent = c.flag; }
      if (n) { n.textContent = c.localName; }
    },
    // ---------- Utilidades ----------
    showToast: function (msg) {
      var t = document.getElementById('toast');
      if (!t) { return; }
      t.textContent = msg;
      t.classList.remove('hidden');
      clearTimeout(App._toastTimer);
      App._toastTimer = setTimeout(function () { t.classList.add('hidden'); }, 2600);
    },
    blockContactInfo: function (text) {
      if (!text) { return false; }
      var re = /([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})|(\+?\d[\d\s\-().]{7,}\d)|(https?:\/\/)|(www\.)|(\.(com|net|org|io|uy|ar|br|es|cl|co|pe|ve|mx)\b)/i;
      return re.test(text);
    },
    formatNumber: function (n) {
      if (n >= 1000000) { return (n / 1000000).toFixed(1) + 'M'; }
      if (n >= 1000) { return (n / 1000).toFixed(1) + 'K'; }
      return String(n);
    },
    isAuthed: function () { return !!App.currentUser; },
    logout: function () {
      App.currentUser = null;
      try { localStorage.removeItem('dimon_user'); } catch (e) {}
      var av = document.getElementById('avatar-mini');
      if (av) { av.textContent = '?'; }
      App.showToast(App.t('profile.loggedOut'));
      App.switchScreen('screen-login');
    },
    // ---------- Drawer ----------
    openDrawer: function () {
      var d = document.getElementById('drawer');
      var o = document.getElementById('drawer-overlay');
      if (d) { d.classList.add('open'); }
      if (o) { o.classList.remove('hidden'); }
    },
    closeDrawer: function () {
      var d = document.getElementById('drawer');
      var o = document.getElementById('drawer-overlay');
      if (d) { d.classList.remove('open'); }
      if (o) { o.classList.add('hidden'); }
    },
    // ---------- Acceso oculto a Dimon General ----------
    openDimonGeneral: function () { App.switchScreen('screen-dimon-general'); },
    _logoTaps: 0,
    _logoTapTimer: null,
    init: function () {
      // Restaurar sesión e idioma
      try {
        var u = localStorage.getItem('dimon_user');
        if (u) { App.currentUser = JSON.parse(u); }
        var lg = localStorage.getItem('dimon_lang');
        if (lg) { App.state.lang = lg; }
        var co = localStorage.getItem('dimon_country');
        if (co) { App.state.country = co; }
      } catch (e) {}

      // Navegación por atributos data-go
      document.body.addEventListener('click', function (e) {
        var go = e.target.closest('[data-go]');
        if (go) { App.switchScreen(go.getAttribute('data-go')); return; }
        var back = e.target.closest('[data-back]');
        if (back) { App.goBack(); return; }
        var close = e.target.closest('[data-close]');
        if (close) {
          var m = document.getElementById(close.getAttribute('data-close'));
          if (m) { m.classList.add('hidden'); }
          return;
        }
        var copy = e.target.closest('[data-copy]');
        if (copy) {
          var txt = copy.getAttribute('data-copy');
          if (navigator.clipboard) { navigator.clipboard.writeText(txt).catch(function () {}); }
          App.showToast(App.t('app.copied'));
          return;
        }
      });

      // Drawer
      var menuBtn = document.getElementById('btn-menu');
      if (menuBtn) { menuBtn.addEventListener('click', App.openDrawer); }
      var overlay = document.getElementById('drawer-overlay');
      if (overlay) { overlay.addEventListener('click', App.closeDrawer); }
      var drawerLogout = document.getElementById('drawer-logout');
      if (drawerLogout) { drawerLogout.addEventListener('click', function () {
        if (App.isAuthed()) { App.logout(); } else { App.showToast(App.t('login.title')); App.switchScreen('screen-login'); }
      }); }

      // Botones principales de bienvenida
      var start = document.getElementById('btn-start');
      if (start) { start.addEventListener('click', function () { App.switchScreen('screen-feed'); }); }
      var dimonW = document.getElementById('btn-dimon-welcome');
      if (dimonW) { dimonW.addEventListener('click', function () { App.switchScreen('screen-dimon'); }); }
      var flagBtn = document.getElementById('btn-flag-select');
      if (flagBtn) { flagBtn.addEventListener('click', function () {
        var fp = document.getElementById('flag-picker');
        if (fp) { fp.classList.remove('hidden'); }
      }); }

      // Perfil en nav inferior
      var profNav = document.getElementById('btn-profile-nav');
      if (profNav) { profNav.addEventListener('click', function () {
        App.switchScreen(App.isAuthed() ? 'screen-profile' : 'screen-login');
      }); }

      // Acceso oculto a Dimon General: 5 toques en el logo del login
      var logoTap = document.getElementById('login-logo-tap');
      if (logoTap) {
        logoTap.addEventListener('click', function () {
          App._logoTaps++;
          clearTimeout(App._logoTapTimer);
          App._logoTapTimer = setTimeout(function () { App._logoTaps = 0; }, 2500);
          if (App._logoTaps >= 5) { App._logoTaps = 0; App.openDimonGeneral(); }
        });
      }
      // Punto diminuto en Información del creador
      var hiddenBtn = document.getElementById('btn-hidden-admin');
      if (hiddenBtn) { hiddenBtn.addEventListener('click', App.openDimonGeneral); }
      // Hash #admin
      if (location.hash === '#admin') { App.openDimonGeneral(); }
      window.addEventListener('hashchange', function () {
        if (location.hash === '#admin') { App.openDimonGeneral(); }
      });

      // Categorías top en feed
      var catsTop = document.getElementById('btn-categories-top');
      if (catsTop) { catsTop.addEventListener('click', function () { App.switchScreen('screen-categories'); }); }

      // Inicializar traducciones y bandera
      App.applyTranslations();
      App.updateFlagBar();

      // Config del servidor
      if (window.Api && window.Api.getConfig) {
        window.Api.getConfig().then(function (cfg) { if (cfg) { App.state.config = cfg; } }).catch(function () {});
      }

      // Inicializar módulos
      var mods = ['Countries', 'Auth', 'Profile', 'Feed', 'Publish', 'Categories', 'DimonIA', 'Live', 'DimonGeneral', 'Payments'];
      for (var i = 0; i < mods.length; i++) {
        var M = window[mods[i]];
        if (M && typeof M.init === 'function') { try { M.init(); } catch (err) { console.error('init falló', mods[i], err); } }
      }

      App.initGlobe();
    },
    // Globo interactivo: gira solo, arrastrar, pinch zoom, tocar abre selector
    initGlobe: function () {
      var globe = document.getElementById('globe');
      if (!globe) { return; }
      var rot = 0, scale = 1, dragging = false, startX = 0, lastRot = 0, pinchDist = 0;
      function render() { globe.style.transform = 'scale(' + scale + ') rotateY(' + rot + 'deg)'; }
      var raf = null;
      function autoSpin() { rot += 0.3; render(); raf = requestAnimationFrame(autoSpin); }
      autoSpin();
      function onStart(x, y, touches) {
        dragging = true; startX = x; lastRot = rot;
        if (raf) { cancelAnimationFrame(raf); raf = null; }
        if (touches && touches.length === 2) {
          pinchDist = Math.hypot(touches[0].clientX - touches[1].clientX, touches[0].clientY - touches[1].clientY);
        }
      }
      function onMove(x, y, touches) {
        if (!dragging) { return; }
        if (touches && touches.length === 2 && pinchDist > 0) {
          var d = Math.hypot(touches[0].clientX - touches[1].clientX, touches[0].clientY - touches[1].clientY);
          scale = Math.max(0.7, Math.min(1.8, scale * (d / pinchDist)));
          pinchDist = d;
          render();
          return;
        }
        rot = lastRot + (x - startX) * 0.8;
        render();
      }
      function onEnd() {
        if (!dragging) { return; }
        dragging = false;
        if (!raf) { autoSpin(); }
      }
      globe.addEventListener('touchstart', function (e) {
        if (e.touches.length === 1) { onStart(e.touches[0].clientX, e.touches[0].clientY, null); }
        else { onStart(0, 0, e.touches); }
      }, { passive: true });
      globe.addEventListener('touchmove', function (e) {
        e.preventDefault();
        if (e.touches.length === 1) { onMove(e.touches[0].clientX, e.touches[0].clientY, null); }
        else { onMove(0, 0, e.touches); }
      }, { passive: false });
      globe.addEventListener('touchend', onEnd);
      globe.addEventListener('mousedown', function (e) { onStart(e.clientX, e.clientY, null); });
      window.addEventListener('mousemove', function (e) { onMove(e.clientX, e.clientY, null); });
      window.addEventListener('mouseup', onEnd);
      globe.addEventListener('click', function () {
        var fp = document.getElementById('flag-picker');
        if (fp && !dragging) { fp.classList.remove('hidden'); }
      });
    }
  };

  window.App = App;
  document.addEventListener('DOMContentLoaded', App.init);
})();

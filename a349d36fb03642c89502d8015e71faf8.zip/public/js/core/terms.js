'use strict';
// Textos legales, glosario FAQ y las 11 áreas de especialistas de Dimon IA.
// Todo en un solo lugar para que el usuario pueda pegar su versión verbatim.
(function () {
  var TERMS_ES = [
    ['1. Objeto y naturaleza de la plataforma', 'Dimon Connet — Servicios Autónomos es una plataforma de intermediación que conecta personas que ofrecen y necesitan servicios de todo tipo, siempre que sean legales. La plataforma no maneja el dinero del servicio entre las partes: solo facilita el encuentro, la comunicación, los acuerdos y el enlace a las pasarelas de pago.'],
    ['2. Valor legal de los acuerdos', 'Los acuerdos celebrados entre usuarios dentro de la plataforma tienen valor legal, quedando amparados en el Código Civil de Uruguay, artículo 1257 (contratos), así como en la Ley 18.600 como marco normativo aplicable a los servicios. Cada parte es responsable de cumplir lo acordado.'],
    ['3. Acta de trato (contrato de servicio)', 'Todo trato concretado debe documentarse en el Acta de trato dentro de la plataforma, especificando obligatoriamente: QUÉ servicio se realiza, CUÁNTO se paga por él, CUÁNDO se realiza y la FECHA del acuerdo. Sin estos datos el trato no se considera formalizado.'],
    ['4. Comisión de intermediación', 'Por el servicio de intermediación, la plataforma cobra {feeHirer}% a quien solicita el servicio y {feeWorker}% a quien lo brinda, lo que representa un {feeTotal}% total. La comisión se cobra ÚNICAMENTE cuando el trato se concreta y ambas partes confirman que el servicio fue realizado y aceptado. Si no hay trato, no hay cobro. Si el acuerdo no tiene valor monetario, no se cobra nada.'],
    ['5. Falta de pago de la comisión', 'El incumplimiento en el pago de la comisión de intermediación dará lugar a: (a) intereses moratorios, (b) gastos de cobro, y (c) restricción o suspensión del uso de la plataforma hasta que la situación se regularice. La plataforma podrá limitar la publicación de nuevos servicios y el acceso a funcionalidades.'],
    ['6. Datos personales', 'Los datos personales se eliminan definitivamente al eliminar la cuenta. No se conservan copias de respaldo permanentes de los datos del usuario. Las cuentas inactivas por más de 6 meses se cierran previo aviso al correo registrado. El usuario puede solicitar la baja en cualquier momento.'],
    ['7. Prohibición de datos de contacto en publicaciones', 'Queda prohibido incluir números de teléfono, correos electrónicos ni enlaces externos en títulos o descripciones de publicaciones. La plataforma detecta y bloquea automáticamente estos datos. La comunicación entre partes se realiza por el chat interno y se desbloquea recién después de concretado el trato.'],
    ['8. Uso de Dimon IA', 'Dimon IA es un asistente virtual que ayuda a buscar, publicar, traducir y resolver dudas. Sus respuestas son orientativas y no reemplazan el acuerdo directo entre las partes ni el asesoramiento profesional.'],
    ['9. Propiedad del contenido', 'Cada usuario es titular del contenido que publica y otorga a la plataforma una licencia no exclusiva para mostrarlo dentro del servicio. Las publicaciones del muro duran 14 días y las del perfil hasta 365 días, según la opción elegida.'],
    ['10. Responsabilidad entre partes', 'La plataforma solo intermedia. No es parte del contrato de servicio, no garantiza la calidad de los servicios ni maneja el dinero del servicio entre las personas. Cada parte responde por sus propios actos frente a la otra.'],
    ['11. Resolución de disputas', 'Las disputas entre usuarios se resuelven primero por el canal interno de la plataforma. De no haber acuerdo, las partes quedan sometidas a la legislación uruguaya y a los tribunales competentes.'],
    ['12. Contacto', 'Consultas legales y notificaciones: dimon.connet@gmail.com']
  ];

  var LEGAL_ES = [
    'Normas legales de Dimon Connet — resumen:',
    '· Los acuerdos entre usuarios tienen valor legal (Código Civil de Uruguay art. 1257; Ley 18.600 aplicable).',
    '· El Acta de trato debe indicar QUÉ se hace, CUÁNTO se paga, CUÁNDO y FECHA del acuerdo.',
    '· Comisión: {feeHirer}% quien solicita + {feeWorker}% quien brinda = {feeTotal}% total, solo al concretarse el trato.',
    '· Sin pago de la comisión: intereses, gastos de cobro y suspensión hasta regularizar.',
    '· Prohibido publicar teléfonos, correos o enlaces. La plataforma los bloquea automáticamente.',
    '· Los datos se borran al eliminar la cuenta; cuentas inactivas 6 meses se cierran con aviso.',
    '· La plataforma solo intermedia: no maneja el dinero del servicio entre las partes.'
  ].join('<br>');

  var ADVICE_ES = [
    'Asesoría legal en lenguaje sencillo:',
    '1. Cuando acuerdes un servicio, completá el Acta de trato: qué se hace, cuánto se paga, cuándo y la fecha. Eso te protege.',
    '2. No compartas tu teléfono, correo ni enlaces en las publicaciones. Usá el chat interno de la plataforma.',
    '3. La comisión es de {feeHirer}% para quien pide el servicio y {feeWorker}% para quien trabaja ({feeTotal}% total), y solo se paga cuando el trato se concreta y ambos confirman.',
    '4. Si no pagás la comisión, pueden aplicarte intereses y gastos de cobro, y te pueden suspender hasta que regularices.',
    '5. Los acuerdos tienen valor legal según el Código Civil de Uruguay (art. 1257) y la Ley 18.600.',
    '6. Si hay un problema, usá primero el canal interno de la plataforma; luego la vía legal correspondiente.',
    '7. Consultas: dimon.connet@gmail.com'
  ].join('<br>');

  var FAQ = [
    ['Dimon', 'Asistente virtual de la plataforma (Dimon IA) que ayuda a buscar, publicar, traducir y resolver dudas en varios idiomas.'],
    ['Dimon General', 'Zona privada del dueño de la plataforma, con acceso protegido por contraseña. No aparece en el menú de usuarios comunes.'],
    ['Colaboradores', 'Las 11 áreas de especialistas conceptuales que asisten a Dimon IA (desarrollo, diseño, redacción, legal, finanzas, etc.). No son personas ni archivos de código.'],
    ['Repositorio', 'El código fuente del proyecto, organizado en carpetas y versionado con Git. Se aloja en GitHub y se despliega en Render.'],
    ['Render', 'Servicio de hosting donde se despliega la plataforma (Web Service conectado al repositorio de GitHub).'],
    ['API', 'Interfaz que permite al navegador comunicarse con el servidor (registro, login, publicaciones, chat de Dimon IA, etc.).'],
    ['Acta de trato', 'Documento del acuerdo de servicio dentro de la plataforma: qué se hace, cuánto se paga, cuándo y la fecha. Tiene valor legal.'],
    ['Huella digital', 'Método rápido de ingreso (biometría del dispositivo) como alternativa a la contraseña.'],
    ['Planeta interactivo', 'Globo en la pantalla de bienvenida: gira, se arrastra, pellizcar hace zoom, y elegir país cambia el idioma de toda la app.'],
    ['Comisión', '{feeHirer}% para quien solicita el servicio + {feeWorker}% para quien lo brinda = {feeTotal}% total para la plataforma. Se cobra solo cuando el trato se concreta y ambas partes confirman. (El manual decía 15%, un .env intermedio 10%, y el texto legal final establece {feeHirer}%/{feeWorker}%.)']
  ];

  var AREAS = [
    'Desarrollo y Tecnología', 'Diseño y Creatividad', 'Redacción y Traducción', 'Ventas y Marketing',
    'Administración y Apoyo', 'Finanzas y Contabilidad', 'Legal', 'Ingeniería y Arquitectura',
    'Ciencia de Datos', 'Atención al Cliente', 'RRHH y Formación'
  ];

  function fmt(html) {
    if (!window.App || !window.App.formatFees) { return html; }
    return window.App.formatFees(html);
  }

  window.Terms = {
    TERMS_ES: TERMS_ES,
    AREAS: AREAS,
    init: function () {
      var termsEl = document.getElementById('terms-text');
      if (termsEl) {
        var html = '<h3>Términos y Condiciones</h3><p class="muted small">Normas legales de Dimon Connet — Servicios Autónomos</p>';
        for (var i = 0; i < TERMS_ES.length; i++) {
          html += '<p><strong>' + TERMS_ES[i][0] + '</strong><br>' + TERMS_ES[i][1] + '</p>';
        }
        termsEl.innerHTML = fmt(html);
      }
      var legalEl = document.getElementById('legal-text');
      if (legalEl) { legalEl.innerHTML = fmt(LEGAL_ES); }
      var adviceEl = document.getElementById('legal-advice-text');
      if (adviceEl) { adviceEl.innerHTML = fmt(ADVICE_ES); }
      var faqEl = document.getElementById('faq-list');
      if (faqEl) {
        var fhtml = '';
        for (var j = 0; j < FAQ.length; j++) {
          fhtml += '<div class="faq-item"><h4>' + FAQ[j][0] + '</h4><p>' + FAQ[j][1] + '</p></div>';
        }
        faqEl.innerHTML = fmt(fhtml);
      }
      var areasEl = document.getElementById('about-areas');
      if (areasEl) {
        var ahtml = '';
        for (var k = 0; k < AREAS.length; k++) {
          ahtml += '<li>' + (k + 1) + '. ' + AREAS[k] + '</li>';
        }
        areasEl.innerHTML = ahtml;
      }
    }
  };
})();

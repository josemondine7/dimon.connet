'use strict';
// Traducciones de UI: es / pt / en / fr. Comisiones dinámicas vía {feeHirer}/{feeWorker}/{feeTotal}.
(function () {
  var es = {
    app: { title: 'Dimon Connet', subtitle: 'Servicios Autónomos', copied: 'Copiado al portapapeles' },
    welcome: { phrase: 'Conectando personas, construyendo oportunidades.', desc: 'Ofrecé o pedí cualquier servicio legal. Entrá, mirá y conectate.', globeHint: 'Tirá el planeta · pellizcá para zoom · tocá para elegir país', start: 'Iniciar' },
    feed: { cats: 'Categorías', world: 'Mundo', country: 'País', city: 'Ciudad', searchPlaceholder: 'Buscar servicios...' },
    nav: { live: 'En vivo', featured: 'Destacar', publish: 'Publicar', profile: 'Perfil' },
    login: { title: 'Iniciar sesión', photo: 'Foto de usuario', user: 'Nombre de usuario', pass: 'Contraseña', recovery: 'Recuperar contraseña', enter: 'Ingresar', noAccount: '¿No tenés cuenta?', create: 'Crear cuenta' },
    register: { title: 'Crear cuenta', photo: 'Foto (opcional)', user: 'Nombre de usuario', email: 'Correo electrónico', google: 'Continuar con Google', pass: 'Contraseña', code: 'Código enviado por correo', sendCode: 'Enviar código', fingerprint: 'Activar huella digital', terms: 'Acepto los Términos y Condiciones', termsLink: 'Ver términos', create: 'Crear cuenta' },
    profile: { title: 'Mi perfil', edit: 'Editar datos', wall: 'Muro', perfil: 'Perfil', messages: 'Mensajes recientes', deals: 'Tratos en curso', payments: 'Pagos realizados', featured: 'Destacados activos', methods: 'Métodos de pago', addMethod: '+ Agregar método', logout: 'Cerrar sesión', delete: 'Eliminar cuenta', save: 'Guardar', loggedOut: 'Sesión cerrada' },
    other: { title: 'Perfil', posts: 'Publicaciones', chat: 'Chat interno' },
    publish: { title: 'Crear publicación', media: 'Foto o video (cámara o galería)', desc: 'Descripción', offer: 'Ofrezco', need: 'Necesito', category: 'Categoría', d14: '14 días en el muro', d365: '365 días en perfil', submit: 'Publicar', blocked: 'No se permiten teléfonos, correos ni enlaces', limit: 'Máximo 15 publicaciones activas' },
    cats: { title: 'Categorías' },
    live: { viewers: 'espectadores', transcribe: 'Transcribir / Traducir con Dimon' },
    featured: { title: 'Destacados', demo: 'Precios demo (sandbox). PayPal simulado.', p1t: 'Opción 1 — Aparecer primero', p1d: 'Tu publicación aparece primera durante 24 h.', p2t: 'Opción 2 — Hasta 10x al día', p2d: 'Aparece hasta 10 veces por día en el muro.', p3t: 'Opción 3 — Primero + más veces', p3d: 'Combinado: primero y hasta 10x al día.', buy: 'Elegir' },
    paypal: { amount: 'Monto:', pay: 'Pagar (simulado)', note: 'No se procesa un pago real en esta demo.' },
    creator: { enterPass: 'Ingresá usuario y contraseña de Dimon General', mustChange: 'Por seguridad, cambiá la contraseña por defecto.', day: 'Hoy', week: 'Semana', month: 'Mes', analytics: 'Analítica de uso', repo: 'Repositorio / Código', tasks: 'Tareas y mejoras', versions: 'Historial de versiones', payments: 'Ingresos', management: 'Gestión', catsEdit: 'Categorías (editable) — 10 activas', legalVer: 'Textos legales — versión 3.1', reports: 'Reportes de contenido — 2 pendientes', security: 'Seguridad — Sesiones', closeSessions: 'Cerrar otras sesiones', userField: 'Usuario' },
    dimon: { done: 'Terminamos', hint: '1 toque: escucha · 2 toques: conversación', voice: 'Voz:', vAdult: 'Adulta', vSenior: 'Mayor', vYoung: 'Joven', type: 'Escribí tu mensaje...' },
    recovery: { title: 'Recuperar contraseña', desc: 'Ingresá tu correo y te enviaremos un enlace para restablecerla.', send: 'Enviar enlace', sent: 'Enlace enviado (simulado)' },
    search: { title: 'Buscar servicios', ph: '¿Qué buscás?' },
    fav: { title: 'Favoritos', empty: 'Aún no guardaste favoritos.' },
    hist: { title: 'Historial' },
    language: { title: 'Idioma y país', choose: 'Elegí tu país' },
    settings: { title: 'Ajustes de cuenta', notif: 'Notificaciones', sound: 'Sonido', voiceDimon: 'Voz de Dimon IA' },
    security: { title: 'Seguridad', fingerprint: 'Huella digital', twoStep: 'Verificación en dos pasos', changePass: 'Cambiar contraseña', note: 'Las publicaciones no muestran teléfono, correo ni enlaces.' },
    legal: { title: 'Normas legales' },
    about: { title: 'Quiénes somos', areas: 'Cómo funciona Dimon IA — 11 áreas de especialistas' },
    projects: { title: 'Proyectos', desc: 'Crear un proyecto, describirlo, invitar personas, tener sala de reunión y comunicarse dentro del proyecto es GRATIS siempre.', commission: 'Solo se cobra cuando dos personas del proyecto acuerdan un servicio o aporte con valor concreto: {feeHirer}% paga quien recibe el beneficio y {feeWorker}% paga quien realiza el trabajo ({feeTotal}% total para la plataforma). Si el acuerdo no tiene valor monetario, no se cobra nada.', note: 'Nota: el manual mencionaba 15% por lado y antes se manejaba una alternativa de US$ 30 por contacto. Hoy rige {feeHirer}%/{feeWorker}% según la configuración final.', extra: 'Los proyectos pueden usar destacados y transmisiones en vivo con los mismos costos vigentes.' },
    companies: { title: 'Comercios y Empresas', fee: 'Cuota: US$ 45 por mes', for: 'Para comercios, negocios o empresas ya constituidas que quieren presencia oficial destacada.', b1: 'Perfil verificado con etiqueta "Empresa Verificada"', b2: 'Publicaciones ilimitadas', b3: 'Estadísticas completas del perfil y sus publicaciones', b4: 'Mayor visibilidad en búsquedas de su zona', note: 'La cuota no incluye comisiones por servicios: cada trato sigue sujeto al {feeHirer}% de cada lado.' },
    legalAdvice: { title: 'Asesoría legal' },
    terms: { title: 'Términos y Condiciones' },
    creatorInfo: { title: 'Información del creador', desc: 'Creador de Dimon Connet — Servicios Autónomos.' },
    faq: { title: 'Ayuda / Preguntas frecuentes' },
    menu: { home: 'Inicio', login: 'Iniciar sesión', register: 'Crear cuenta', filters: 'Filtros y búsqueda', search: 'Buscar servicios', fav: 'Favoritos', history: 'Historial', language: 'Menú de idioma', account: 'Ajustes de cuenta', legal: 'Normas legales', about: 'Quiénes somos', config: 'Configuración', security: 'Seguridad', logout: 'Cerrar sesión', dimon: 'Voz de Dimon IA', projects: 'Proyectos', companies: 'Comercios y Empresas', legalAdvice: 'Asesoría Legal', terms: 'Términos y Condiciones', faq: 'Ayuda / Preguntas frecuentes', creatorInfo: 'Información del creador' }
  };

  var pt = {
    app: { title: 'Dimon Connet', subtitle: 'Serviços Autônomos', copied: 'Copiado' },
    welcome: { phrase: 'Conectando pessoas, construindo oportunidades.', desc: 'Ofereça ou peça qualquer serviço legal. Entre, veja e conecte-se.', globeHint: 'Arraste o planeta · pinça para zoom · toque para escolher país', start: 'Iniciar' },
    login: { title: 'Entrar', photo: 'Foto do usuário', user: 'Nome de usuário', pass: 'Senha', recovery: 'Recuperar senha', enter: 'Entrar', noAccount: 'Não tem conta?', create: 'Criar conta' },
    register: { title: 'Criar conta', email: 'E-mail', pass: 'Senha', create: 'Criar conta', sendCode: 'Enviar código', fingerprint: 'Ativar impressão digital' },
    profile: { title: 'Meu perfil', edit: 'Editar dados', logout: 'Sair', save: 'Salvar', messages: 'Mensagens recentes', deals: 'Negócios em andamento' },
    publish: { title: 'Criar publicação', offer: 'Ofereço', need: 'Preciso', submit: 'Publicar', category: 'Categoria', blocked: 'Telefones, e-mails e links não são permitidos' },
    cats: { title: 'Categorias' },
    featured: { title: 'Destaques', buy: 'Escolher' },
    dimon: { done: 'Terminamos', hint: '1 toque: escuta · 2 toques: conversa', voice: 'Voz:', type: 'Escreva sua mensagem...' },
    search: { title: 'Buscar serviços', ph: 'O que você procura?' },
    language: { title: 'Idioma e país', choose: 'Escolha seu país' },
    menu: { home: 'Início', login: 'Entrar', register: 'Criar conta', search: 'Buscar serviços', fav: 'Favoritos', history: 'Histórico', language: 'Idioma', account: 'Ajustes da conta', legal: 'Normas legais', about: 'Quem somos', security: 'Segurança', logout: 'Sair', projects: 'Projetos', companies: 'Comércios e Empresas', terms: 'Termos e Condições', faq: 'Ajuda / Perguntas frequentes', creatorInfo: 'Informação do criador' },
    projects: { commission: 'Só se cobra quando duas pessoas acordam um serviço com valor: {feeHirer}% paga quem recebe e {feeWorker}% paga quem realiza ({feeTotal}% total).' },
    companies: { fee: 'Mensalidade: US$ 45 por mês' }
  };

  var en = {
    app: { title: 'Dimon Connet', subtitle: 'Freelance Services', copied: 'Copied' },
    welcome: { phrase: 'Connecting people, building opportunities.', desc: 'Offer or request any legal service. Jump in, browse and connect.', globeHint: 'Drag the globe · pinch to zoom · tap to pick a country', start: 'Start' },
    login: { title: 'Sign in', photo: 'User photo', user: 'Username', pass: 'Password', recovery: 'Forgot password', enter: 'Sign in', noAccount: "Don't have an account?", create: 'Create account' },
    register: { title: 'Create account', email: 'Email', pass: 'Password', create: 'Create account', sendCode: 'Send code', fingerprint: 'Enable fingerprint' },
    profile: { title: 'My profile', edit: 'Edit details', logout: 'Log out', save: 'Save', messages: 'Recent messages', deals: 'Ongoing deals' },
    publish: { title: 'Create post', offer: 'I offer', need: 'I need', submit: 'Publish', category: 'Category', blocked: 'Phones, emails and links are not allowed' },
    cats: { title: 'Categories' },
    featured: { title: 'Featured', buy: 'Choose' },
    dimon: { done: 'Done', hint: '1 tap: listen · 2 taps: conversation', voice: 'Voice:', type: 'Type your message...' },
    search: { title: 'Search services', ph: 'What are you looking for?' },
    language: { title: 'Language & country', choose: 'Choose your country' },
    menu: { home: 'Home', login: 'Sign in', register: 'Create account', search: 'Search services', fav: 'Favorites', history: 'History', language: 'Language', account: 'Account settings', legal: 'Legal', about: 'About us', security: 'Security', logout: 'Log out', projects: 'Projects', companies: 'Businesses', terms: 'Terms & Conditions', faq: 'Help / FAQ', creatorInfo: 'Creator info' },
    projects: { commission: 'We only charge when two people agree on a valued service: {feeHirer}% paid by the receiver and {feeWorker}% by the provider ({feeTotal}% total).' },
    companies: { fee: 'Monthly fee: US$ 45' }
  };

  var fr = {
    app: { title: 'Dimon Connet', subtitle: 'Services Indépendants', copied: 'Copié' },
    welcome: { phrase: 'Connecter les personnes, créer des opportunités.', desc: 'Proposez ou demandez un service légal. Entrez et connectez-vous.', start: 'Commencer' },
    login: { title: 'Connexion', user: "Nom d'utilisateur", pass: 'Mot de passe', enter: 'Se connecter', create: 'Créer un compte' },
    register: { title: 'Créer un compte', email: 'E-mail', pass: 'Mot de passe', create: 'Créer un compte' },
    profile: { title: 'Mon profil', logout: 'Déconnexion', save: 'Enregistrer' },
    publish: { title: 'Créer une publication', submit: 'Publier' },
    cats: { title: 'Catégories' },
    menu: { home: 'Accueil', login: 'Connexion', register: 'Créer un compte', search: 'Rechercher', fav: 'Favoris', history: 'Historique', language: 'Langue', about: 'Qui sommes-nous', terms: 'Conditions', faq: 'Aide / FAQ' },
    projects: { commission: 'Nous ne facturons que lors d’un accord concret : {feeHirer}% par le receveur et {feeWorker}% par le prestataire ({feeTotal}% au total).' }
  };

  window.Translations = { es: es, pt: pt, en: en, fr: fr };
})();

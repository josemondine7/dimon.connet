'use strict';
// Lista de países soportados: bandera emoji, código, nombre local e idioma de UI.
// La UI se traduce a es/pt/en/fr; otros idiomas muestran nombre local y UI en inglés.
(function () {
  var LIST = [
    { code: 'AR', flag: '🇦🇷', localName: 'Argentina', lang: 'es' },
    { code: 'BO', flag: '🇧🇴', localName: 'Bolivia', lang: 'es' },
    { code: 'CL', flag: '🇨🇱', localName: 'Chile', lang: 'es' },
    { code: 'CO', flag: '🇨🇴', localName: 'Colombia', lang: 'es' },
    { code: 'CR', flag: '🇨🇷', localName: 'Costa Rica', lang: 'es' },
    { code: 'CU', flag: '🇨🇺', localName: 'Cuba', lang: 'es' },
    { code: 'DO', flag: '🇩🇴', localName: 'República Dominicana', lang: 'es' },
    { code: 'EC', flag: '🇪🇨', localName: 'Ecuador', lang: 'es' },
    { code: 'ES', flag: '🇪🇸', localName: 'España', lang: 'es' },
    { code: 'GT', flag: '🇬🇹', localName: 'Guatemala', lang: 'es' },
    { code: 'HN', flag: '🇭🇳', localName: 'Honduras', lang: 'es' },
    { code: 'MX', flag: '🇲🇽', localName: 'México', lang: 'es' },
    { code: 'NI', flag: '🇳🇮', localName: 'Nicaragua', lang: 'es' },
    { code: 'PA', flag: '🇵🇦', localName: 'Panamá', lang: 'es' },
    { code: 'PE', flag: '🇵🇪', localName: 'Perú', lang: 'es' },
    { code: 'PY', flag: '🇵🇾', localName: 'Paraguay', lang: 'es' },
    { code: 'SV', flag: '🇸🇻', localName: 'El Salvador', lang: 'es' },
    { code: 'UY', flag: '🇺🇾', localName: 'Uruguay', lang: 'es' },
    { code: 'VE', flag: '🇻🇪', localName: 'Venezuela', lang: 'es' },
    { code: 'BR', flag: '🇧🇷', localName: 'Brasil', lang: 'pt' },
    { code: 'AO', flag: '🇦🇴', localName: 'Angola', lang: 'pt' },
    { code: 'MZ', flag: '🇲🇿', localName: 'Moçambique', lang: 'pt' },
    { code: 'PT', flag: '🇵🇹', localName: 'Portugal', lang: 'pt' },
    { code: 'US', flag: '🇺🇸', localName: 'United States', lang: 'en' },
    { code: 'GB', flag: '🇬🇧', localName: 'United Kingdom', lang: 'en' },
    { code: 'CA', flag: '🇨🇦', localName: 'Canada', lang: 'en' },
    { code: 'AU', flag: '🇦🇺', localName: 'Australia', lang: 'en' },
    { code: 'NZ', flag: '🇳🇿', localName: 'New Zealand', lang: 'en' },
    { code: 'NG', flag: '🇳🇬', localName: 'Nigeria', lang: 'en' },
    { code: 'KE', flag: '🇰🇪', localName: 'Kenya', lang: 'en' },
    { code: 'FR', flag: '🇫🇷', localName: 'France', lang: 'fr' },
    { code: 'IT', flag: '🇮🇹', localName: 'Italia', lang: 'en' },
    { code: 'DE', flag: '🇩🇪', localName: 'Deutschland', lang: 'en' },
    { code: 'NL', flag: '🇳🇱', localName: 'Nederland', lang: 'en' },
    { code: 'RU', flag: '🇷🇺', localName: 'Россия', lang: 'en' },
    { code: 'CN', flag: '🇨🇳', localName: '中国', lang: 'en' },
    { code: 'JP', flag: '🇯🇵', localName: '日本', lang: 'en' },
    { code: 'KR', flag: '🇰🇷', localName: '대한민국', lang: 'en' },
    { code: 'IN', flag: '🇮🇳', localName: 'India', lang: 'en' },
    { code: 'TR', flag: '🇹🇷', localName: 'Türkiye', lang: 'en' },
    { code: 'SA', flag: '🇸🇦', localName: 'السعودية', lang: 'en' },
    { code: 'AE', flag: '🇦🇪', localName: 'الإمارات', lang: 'en' },
    { code: 'IL', flag: '🇮🇱', localName: 'ישראל', lang: 'en' },
    { code: 'EG', flag: '🇪🇬', localName: 'مصر', lang: 'en' },
    { code: 'MA', flag: '🇲🇦', localName: 'المغرب', lang: 'en' },
    { code: 'PL', flag: '🇵🇱', localName: 'Polska', lang: 'en' },
    { code: 'SE', flag: '🇸🇪', localName: 'Sverige', lang: 'en' },
    { code: 'NO', flag: '🇳🇴', localName: 'Norge', lang: 'en' },
    { code: 'DK', flag: '🇩🇰', localName: 'Danmark', lang: 'en' },
    { code: 'FI', flag: '🇫🇮', localName: 'Suomi', lang: 'en' },
    { code: 'GR', flag: '🇬🇷', localName: 'Ελλάδα', lang: 'en' },
    { code: 'CZ', flag: '🇨🇿', localName: 'Česko', lang: 'en' },
    { code: 'HU', flag: '🇭🇺', localName: 'Magyarország', lang: 'en' },
    { code: 'RO', flag: '🇷🇴', localName: 'România', lang: 'en' },
    { code: 'BG', flag: '🇧🇬', localName: 'България', lang: 'en' },
    { code: 'HR', flag: '🇭🇷', localName: 'Hrvatska', lang: 'en' },
    { code: 'RS', flag: '🇷🇸', localName: 'Србија', lang: 'en' },
    { code: 'SK', flag: '🇸🇰', localName: 'Slovensko', lang: 'en' },
    { code: 'SI', flag: '🇸🇮', localName: 'Slovenija', lang: 'en' },
    { code: 'LT', flag: '🇱🇹', localName: 'Lietuva', lang: 'en' },
    { code: 'LV', flag: '🇱🇻', localName: 'Latvija', lang: 'en' },
    { code: 'EE', flag: '🇪🇪', localName: 'Eesti', lang: 'en' }
  ];
  var byCode = {};
  for (var i = 0; i < LIST.length; i++) { byCode[LIST[i].code] = LIST[i]; }

  window.Countries = {
    list: LIST,
    byCode: byCode,
    init: function () {
      // Grilla de banderas en el selector
      var grid = document.getElementById('flag-grid');
      if (grid) {
        grid.innerHTML = '';
        for (var i = 0; i < LIST.length; i++) {
          (function (c) {
            var b = document.createElement('button');
            b.textContent = c.flag;
            b.title = c.localName;
            b.addEventListener('click', function () {
              window.App.setLang(c.lang, c.code);
              var fp = document.getElementById('flag-picker');
              if (fp) { fp.classList.add('hidden'); }
              window.App.showToast(c.localName + ' — ' + c.lang.toUpperCase());
            });
            grid.appendChild(b);
          })(LIST[i]);
        }
      }
      // Lista de países en pantalla de idioma
      var langList = document.getElementById('language-list');
      if (langList) {
        langList.innerHTML = '';
        for (var j = 0; j < LIST.length; j++) {
          (function (c) {
            var row = document.createElement('div');
            row.className = 'lang-row';
            row.innerHTML = '<span class="flag">' + c.flag + '</span><span>' + c.localName + '</span>';
            row.addEventListener('click', function () {
              window.App.setLang(c.lang, c.code);
              window.App.showToast(c.localName);
            });
            langList.appendChild(row);
          })(LIST[j]);
        }
      }
    }
  };
})();

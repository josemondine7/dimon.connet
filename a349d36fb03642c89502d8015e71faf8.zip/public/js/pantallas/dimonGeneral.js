'use strict';
// Dimon General — zona privada del dueño. Acceso oculto, protegido por JWT de admin.
// ADMIN_DOC (cédula) solo se muestra vía /api/admin/info con token válido, nunca hardcodeado.
(function () {
  var REPO_FILES = [
    'package.json', 'server.js', 'server/db.js', '.env.example', '.gitignore', 'README.md',
    'public/index.html', 'public/css/styles.css',
    'public/js/core/app.js', 'public/js/core/countries.js', 'public/js/core/translations.js', 'public/js/core/terms.js',
    'public/js/servicios/api.js', 'public/js/servicios/payments.js',
    'public/js/colaboradores/dimonIA.js',
    'public/js/pantallas/auth.js', 'public/js/pantallas/profile.js', 'public/js/pantallas/feed.js',
    'public/js/pantallas/publish.js', 'public/js/pantallas/categories.js', 'public/js/pantallas/live.js',
    'public/js/pantallas/dimonGeneral.js',
    'dimon-general/README.md'
  ];
  var VERSIONS = [
    'v1.0 — Lanzamiento inicial: feed, login, publicar, Dimon IA',
    'v1.1 — 3 pasarelas de pago y proxy Groq',
    'v1.2 — Dimon General con JWT y capa de datos JSON',
    'v1.3 — Términos y Condiciones completo + glosario FAQ'
  ];

  function loadTasks() {
    try { return JSON.parse(localStorage.getItem('dimon_tasks') || '[]'); } catch (e) { return []; }
  }
  function saveTasks(t) { try { localStorage.setItem('dimon_tasks', JSON.stringify(t)); } catch (e) {} }

  function renderTasks() {
    var list = document.getElementById('creator-tasks');
    if (!list) { return; }
    var tasks = loadTasks();
    list.innerHTML = '';
    for (var i = 0; i < tasks.length; i++) {
      (function (idx, txt) {
        var li = document.createElement('li');
        li.innerHTML = '<span>' + txt + '</span><button class="btn-small" data-del="' + idx + '">✕</button>';
        li.querySelector('[data-del]').addEventListener('click', function () {
          var t = loadTasks(); t.splice(idx, 1); saveTasks(t); renderTasks();
        });
        list.appendChild(li);
      })(i, tasks[i]);
    }
  }

  async function showPanel() {
    document.getElementById('creator-login').classList.add('hidden');
    document.getElementById('creator-change-pass').classList.add('hidden');
    document.getElementById('creator-panel').classList.remove('hidden');

    // Repositorio
    var repo = document.getElementById('creator-repo');
    if (repo) { repo.innerHTML = REPO_FILES.map(function (f) { return '<li>' + f + '</li>'; }).join(''); }
    // Versiones
    var ver = document.getElementById('creator-versions');
    if (ver) { ver.innerHTML = VERSIONS.map(function (v) { return '<li>' + v + '</li>'; }).join(''); }
    // Tareas
    renderTasks();
    // Ingresos (simulados)
    var pays = document.getElementById('creator-payments');
    if (pays) {
      pays.innerHTML =
        '<li>Cuota comercios (US$45/mes) <span>US$ 180</span></li>' +
        '<li>Comisiones tratos (15%+15%) <span>US$ 92</span></li>' +
        '<li>Destacados <span>US$ 34</span></li>';
    }
    // Stats y sesiones desde el servidor (si hay token)
    if (window.Api && window.Api.adminReq) {
      var st = await window.Api.adminReq('/api/admin/stats');
      var statsEl = document.getElementById('creator-stats');
      if (statsEl) {
        var s = (st && st.ok && st.data) ? st.data : { users: 12, posts: 34, deals: 5, sessions: 8, featured: 3 };
        statsEl.innerHTML =
          '<div class="stat-card"><div class="num">' + s.users + '</div><div class="lbl">Usuarios activos</div></div>' +
          '<div class="stat-card"><div class="num">' + s.posts + '</div><div class="lbl">Publicaciones</div></div>' +
          '<div class="stat-card"><div class="num">' + s.deals + '</div><div class="lbl">Tratos concretados</div></div>' +
          '<div class="stat-card"><div class="num">' + s.sessions + '</div><div class="lbl">Sesiones</div></div>';
      }
      var sess = await window.Api.adminReq('/api/admin/sessions');
      var sessEl = document.getElementById('creator-sessions');
      if (sessEl) {
        var list = (sess && sess.ok && sess.data && sess.data.sessions) ? sess.data.sessions : [{ at: new Date().toISOString(), type: 'admin_login', ua: 'navegador actual' }];
        sessEl.innerHTML = list.slice(0, 8).map(function (x) {
          return '<li>' + (x.type || 'sesión') + ' <span class="muted small">' + new Date(x.at).toLocaleString() + '</span></li>';
        }).join('');
      }
      // Info del admin (incluye ADMIN_DOC — solo acá, con token válido)
      var info = await window.Api.adminReq('/api/admin/info');
      if (info && info.ok && info.data) {
        var d = info.data;
        var pays2 = document.getElementById('creator-payments');
        if (pays2) {
          var li = document.createElement('li');
          li.innerHTML = '<strong>Admin:</strong> ' + (d.name || '') + ' · ' + (d.email || '') + ' · Doc: ' + (d.doc || '—');
          pays2.appendChild(li);
        }
      }
      // Actas y documentos legales (solo con JWT de admin válido; nunca en código cliente)
      var actasEl = document.getElementById('creator-actas');
      if (actasEl) {
        var actasResp = await window.Api.adminReq('/api/admin/actas');
        if (actasResp && actasResp.ok && actasResp.data && actasResp.data.actas && actasResp.data.actas.length) {
          var html = '';
          var al = actasResp.data.actas;
          for (var a = 0; a < al.length; a++) {
            html += '<p><strong>' + al[a].titulo + '</strong><br><em>' + al[a].fecha + '</em><br>' +
              al[a].texto.replace(/\n/g, '<br>') + '</p>';
          }
          actasEl.innerHTML = html;
        } else {
          actasEl.innerHTML = '<p class="muted">Sin actas cargadas.</p>';
        }
      }
    }
  }

  window.DimonGeneral = {
    init: function () {
      var btn = document.getElementById('btn-creator-login');
      if (btn) { btn.addEventListener('click', async function () {
        var user = document.getElementById('creator-user').value.trim();
        var pass = document.getElementById('creator-pass').value;
        if (!user || !pass) { window.App.showToast('Ingresá usuario y contraseña'); return; }
        var r = await window.Api.adminLogin(user, pass);
        if (r && r.ok) {
          window.App.showToast('Acceso concedido');
          showPanel();
        } else {
          window.App.showToast('Credenciales incorrectas');
        }
      }); }

      var addTask = document.getElementById('btn-add-task');
      if (addTask) { addTask.addEventListener('click', function () {
        var inp = document.getElementById('task-input');
        if (inp && inp.value.trim()) {
          var t = loadTasks(); t.push(inp.value.trim()); saveTasks(t); inp.value = ''; renderTasks();
        }
      }); }

      var closeSess = document.getElementById('btn-close-other-sessions');
      if (closeSess) { closeSess.addEventListener('click', function () {
        window.App.showToast('Otras sesiones cerradas (simulado)');
      }); }

      // Filtros día/semana/mes (cambia números simulados)
      var csegs = document.querySelectorAll('[data-cfilter]');
      for (var i = 0; i < csegs.length; i++) {
        csegs[i].addEventListener('click', function (e) {
          var s = e.currentTarget;
          var sibs = s.parentElement.querySelectorAll('.seg');
          for (var j = 0; j < sibs.length; j++) { sibs[j].classList.remove('active'); }
          s.classList.add('active');
        });
      }
    }
  };
})();

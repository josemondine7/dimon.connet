'use strict';
// Autenticación: login, registro, recuperación. Usa la API real; si no hay servidor, modo simulado.
(function () {
  function saveUser(user) {
    window.App.currentUser = user;
    try { localStorage.setItem('dimon_user', JSON.stringify(user)); } catch (e) {}
    var av = document.getElementById('avatar-mini');
    if (av && user && user.username) { av.textContent = user.username.charAt(0).toUpperCase(); }
  }

  window.Auth = {
    init: function () {
      // Restaurar sesión
      try {
        var u = localStorage.getItem('dimon_user');
        if (u) { saveUser(JSON.parse(u)); }
      } catch (e) {}

      var loginForm = document.getElementById('login-form');
      if (loginForm) {
        loginForm.addEventListener('submit', async function (e) {
          e.preventDefault();
          var user = document.getElementById('login-user').value.trim();
          var pass = document.getElementById('login-pass').value;
          if (!user || !pass) { window.App.showToast('Completá usuario y contraseña'); return; }
          var r = await window.Api.login(user, pass);
          if (r && r.ok) {
            saveUser(r.user || { username: user });
            window.App.showToast('Bienvenido, ' + user);
            window.App.switchScreen('screen-feed');
          } else {
            window.App.showToast('Usuario o contraseña incorrectos');
          }
        });
      }

      var regForm = document.getElementById('register-form');
      if (regForm) {
        regForm.addEventListener('submit', async function (e) {
          e.preventDefault();
          var user = document.getElementById('reg-user').value.trim();
          var email = document.getElementById('reg-email').value.trim();
          var pass = document.getElementById('reg-pass').value;
          var terms = document.getElementById('reg-terms-check');
          if (terms && !terms.checked) { window.App.showToast('Debés aceptar los Términos y Condiciones'); return; }
          if (!user || !pass || pass.length < 4) { window.App.showToast('Usuario y contraseña (mín 4 caracteres) requeridos'); return; }
          var r = await window.Api.register(user, email, pass);
          if (r && r.ok) {
            saveUser(r.user || { username: user, email: email });
            window.App.showToast('Cuenta creada. ¡Bienvenido!');
            window.App.switchScreen('screen-feed');
          } else {
            window.App.showToast('No se pudo crear la cuenta (¿ya existe el usuario?)');
          }
        });
      }

      var sendCode = document.getElementById('reg-send-code');
      if (sendCode) { sendCode.addEventListener('click', function () { window.App.showToast('Código enviado (simulado)'); }); }

      var recovery = document.getElementById('btn-recovery-send');
      if (recovery) { recovery.addEventListener('click', function () { window.App.showToast(window.App.t('recovery.sent')); }); }

      // Previsualizar foto de registro
      var regPhoto = document.getElementById('reg-photo');
      if (regPhoto) { regPhoto.addEventListener('change', function (e) {
        var prev = document.getElementById('reg-photo-preview');
        if (prev && e.target.files && e.target.files[0]) { prev.textContent = '📷'; }
      }); }
    }
  };
})();

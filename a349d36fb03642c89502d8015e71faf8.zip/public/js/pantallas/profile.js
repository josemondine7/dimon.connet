'use strict';
// Perfil propio y ajeno, edición, tabs, cerrar sesión, eliminar cuenta.
(function () {
  function renderProfile() {
    var u = window.App.currentUser;
    var nameEl = document.getElementById('profile-name');
    var locEl = document.getElementById('profile-location');
    var av = document.getElementById('profile-avatar');
    if (nameEl) { nameEl.textContent = u ? u.username : 'Invitado'; }
    if (locEl) { locEl.textContent = u && u.email ? u.email : 'Uruguay'; }
    if (av) { av.textContent = u && u.username ? u.username.charAt(0).toUpperCase() : '?'; }

    var posts = document.getElementById('profile-posts');
    if (posts) {
      var myPosts = [];
      try { myPosts = JSON.parse(localStorage.getItem('dimon_my_posts') || '[]'); } catch (e) {}
      posts.innerHTML = '';
      var grads = ['linear-gradient(160deg,#0052cc,#00aaff)', 'linear-gradient(160deg,#2d6a4f,#95d5b2)', 'linear-gradient(160deg,#6a0572,#ab83a1)'];
      for (var i = 0; i < Math.max(myPosts.length, 3); i++) {
        var d = document.createElement('div');
        d.className = 'mini-post';
        d.style.background = grads[i % 3];
        d.textContent = myPosts[i] ? myPosts[i].title.slice(0, 14) : '—';
        posts.appendChild(d);
      }
    }

    var msg = document.getElementById('profile-messages');
    if (msg) { msg.innerHTML = '<li>Dimon IA <span class="muted">hoy</span></li><li data-i18n="profile.messages">Sin mensajes nuevos</li>'; }
    var deals = document.getElementById('profile-deals');
    if (deals) { deals.innerHTML = '<li data-i18n="profile.deals">Sin tratos en curso</li>'; }
    var pays = document.getElementById('profile-payments-list');
    if (pays) { pays.innerHTML = '<li data-i18n="profile.payments">Sin pagos registrados</li>'; }
    var feats = document.getElementById('profile-featured-list');
    if (feats) {
      var f = [];
      try { f = JSON.parse(localStorage.getItem('dimon_featured') || '[]'); } catch (e) {}
      feats.innerHTML = f.length ? f.map(function (x) { return '<li>Plan ' + x.plan + ' <span class="muted">vence ' + new Date(x.expires).toLocaleDateString() + '</span></li>'; }).join('') : '<li class="muted">Sin destacados activos</li>';
    }
  }

  window.Profile = {
    init: function () {
      var editBtn = document.getElementById('btn-edit-profile');
      if (editBtn) { editBtn.addEventListener('click', function () {
        var m = document.getElementById('modal-edit-profile');
        if (m) {
          var u = window.App.currentUser || {};
          document.getElementById('edit-name').value = u.username || '';
          document.getElementById('edit-location').value = u.location || '';
          document.getElementById('edit-bio').value = u.bio || '';
          m.classList.remove('hidden');
        }
      }); }
      var saveBtn = document.getElementById('btn-save-profile');
      if (saveBtn) { saveBtn.addEventListener('click', function () {
        var u = window.App.currentUser || { username: 'Usuario' };
        u.username = document.getElementById('edit-name').value || u.username;
        u.location = document.getElementById('edit-location').value;
        u.bio = document.getElementById('edit-bio').value;
        window.App.currentUser = u;
        try { localStorage.setItem('dimon_user', JSON.stringify(u)); } catch (e) {}
        var m = document.getElementById('modal-edit-profile');
        if (m) { m.classList.add('hidden'); }
        renderProfile();
        window.App.showToast('Perfil actualizado');
      }); }

      var logoutBtn = document.getElementById('btn-logout');
      if (logoutBtn) { logoutBtn.addEventListener('click', function () { window.App.logout(); }); }

      var delBtn = document.getElementById('btn-delete-account');
      if (delBtn) { delBtn.addEventListener('click', function () {
        if (confirm('¿Seguro que querés eliminar tu cuenta? Se borran tus datos.')) {
          try { localStorage.removeItem('dimon_user'); localStorage.removeItem('dimon_token'); } catch (e) {}
          window.App.currentUser = null;
          window.App.showToast('Cuenta eliminada');
          window.App.switchScreen('screen-welcome');
        }
      }); }

      // Tabs
      var tabs = document.querySelectorAll('.tab');
      for (var i = 0; i < tabs.length; i++) {
        tabs[i].addEventListener('click', function (e) {
          var t = e.currentTarget;
          var parent = t.parentElement;
          var sibs = parent.querySelectorAll('.tab');
          for (var j = 0; j < sibs.length; j++) { sibs[j].classList.remove('active'); }
          t.classList.add('active');
        });
      }

      // Chat interno desde perfil ajeno
      var chatOther = document.getElementById('btn-chat-other');
      if (chatOther) { chatOther.addEventListener('click', function () { window.App.switchScreen('screen-dimon'); }); }

      // Renderizar cuando se muestra el perfil
      var observer = new MutationObserver(function () {
        var s = document.getElementById('screen-profile');
        if (s && s.classList.contains('active')) { renderProfile(); }
      });
      observer.observe(document.body, { attributes: true, subtree: true, attributeFilter: ['class'] });
      renderProfile();
    },
    openOther: function (post) {
      document.getElementById('other-name').textContent = post.username;
      document.getElementById('other-location').textContent = post.city + ', ' + post.country;
      document.getElementById('other-bio').textContent = post.title;
      document.getElementById('other-seniority').textContent = 'En la plataforma desde 2025';
      document.getElementById('other-stars').textContent = '★★★★☆ (4.2)';
      document.getElementById('other-offers').textContent = post.type === 'offer' ? 'Ofrece: ' + post.category : 'Necesita: ' + post.category;
      var op = document.getElementById('other-posts');
      if (op) { op.innerHTML = '<div class="mini-post" style="background:' + post.gradient + '">' + post.title.slice(0, 12) + '</div>'; }
      window.App.switchScreen('screen-other-profile');
    }
  };
})();

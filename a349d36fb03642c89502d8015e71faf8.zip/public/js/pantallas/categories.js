'use strict';
// Las 10 categorías con sus subrubros exactos del manual.
(function () {
  var CATEGORIES = [
    { name: 'Servicios técnicos y reparaciones', subs: 'Electrónica, celulares, computación, electrodomésticos, mecánica, plomería, electricidad' },
    { name: 'Servicios del hogar', subs: 'Limpieza, cuidado de niños, adultos mayores, mascotas, jardinería, mudanzas' },
    { name: 'Creativos y diseño', subs: 'Diseño gráfico, logotipos, fotografía, video, ilustración, community management' },
    { name: 'Servicios generales', subs: 'Catering, eventos, mantenimiento, delivery, asesoramiento general' },
    { name: 'Bienestar y salud', subs: 'Yoga, fitness, nutrición, masajes, cuidado personal, deportes' },
    { name: 'Clases y formación', subs: 'Clases particulares, idiomas, música, arte, apoyo escolar, talleres' },
    { name: 'Servicios profesionales', subs: 'Legal, contable, arquitectura, ingeniería, consultoría, marketing' },
    { name: 'Servicios rurales y del campo', subs: 'Tareas rurales, ganadería, agricultura, maquinaria, campo' },
    { name: 'Productos y emprendimientos', subs: 'Venta de productos, emprendimientos, artesanía, comida, moda' },
    { name: 'Otros servicios', subs: 'Cualquier servicio legal no clasificado en las categorías anteriores' }
  ];

  window.Categories = {
    data: CATEGORIES,
    init: function () {
      var list = document.getElementById('cats-list');
      if (list) {
        list.innerHTML = '';
        for (var i = 0; i < CATEGORIES.length; i++) {
          (function (cat) {
            var card = document.createElement('div');
            card.className = 'cat-card';
            card.innerHTML = '<h4>' + cat.name + ' <span>›</span></h4><p>' + cat.subs + '</p>';
            card.addEventListener('click', function () {
              if (window.App) {
                App.state.categoryFilter = cat.name;
                App.showToast('Filtrado: ' + cat.name);
                App.switchScreen('screen-feed');
              }
            });
            list.appendChild(card);
          })(CATEGORIES[i]);
        }
      }
    }
  };
})();

'use strict';
// Muro / feed estilo reels: scroll snap vertical, publicaciones full-screen.
(function () {
  var SAMPLE = [
    { id: 101, username: 'caro_fit', title: 'Clases de yoga personalizadas', desc: 'Sesiones online y a domicilio. Principiantes bienvenidos.', type: 'offer', category: 'Bienestar y salud', city: 'Montevideo', country: 'UY', likes: 124, comments: 18, shares: 5, gradient: 'linear-gradient(160deg,#0052cc,#00aaff)' },
    { id: 102, username: 'techleo', title: 'Reparación de celulares y tablets', desc: 'Cambio de pantalla y batería en el día. Garantía escrita.', type: 'offer', category: 'Servicios técnicos y reparaciones', city: 'São Paulo', country: 'BR', likes: 342, comments: 41, shares: 22, gradient: 'linear-gradient(160deg,#0a2463,#3e92cc)' },
    { id: 103, username: 'maria_limpieza', title: 'Necesito equipo de limpieza', desc: 'Limpieza profunda de casa grande para este fin de semana.', type: 'need', category: 'Servicios del hogar', city: 'Buenos Aires', country: 'AR', likes: 56, comments: 12, shares: 3, gradient: 'linear-gradient(160deg,#2d6a4f,#95d5b2)' },
    { id: 104, username: 'diseño_ana', title: 'Diseño de logotipos y marcas', desc: 'Identidad visual completa para tu emprendimiento. 3 propuestas.', type: 'offer', category: 'Creativos y diseño', city: 'Lima', country: 'PE', likes: 289, comments: 33, shares: 17, gradient: 'linear-gradient(160deg,#6a0572,#ab83a1)' },
    { id: 105, username: 'chef_rodrigo', title: 'Catering para eventos', desc: 'Menú casero para hasta 20 personas. Presupuesto sin cargo.', type: 'offer', category: 'Servicios generales', city: 'Santiago', country: 'CL', likes: 178, comments: 25, shares: 9, gradient: 'linear-gradient(160deg,#b5651d,#f4a261)' },
    { id: 106, username: 'estudio_juridico', title: 'Asesoría legal laboral', desc: 'Primera consulta gratuita por el chat interno de la plataforma.', type: 'offer', category: 'Servicios profesionales', city: 'Madrid', country: 'ES', likes: 95, comments: 14, shares: 6, gradient: 'linear-gradient(160deg,#1d3557,#457b9d)' }
  ];

  function render(posts) {
    var container = document.getElementById('feed-container');
    if (!container) { return; }
    container.innerHTML = '';
    var list = posts && posts.length ? posts : SAMPLE;
    var catFilter = window.App.state.categoryFilter;
    if (catFilter) { list = list.filter(function (p) { return p.category === catFilter; }); }
    if (!list.length) { list = SAMPLE; }
    for (var i = 0; i < list.length; i++) {
      (function (p) {
        var post = document.createElement('div');
        post.className = 'post';
        post.innerHTML =
          '<div class="post-bg" style="background:' + p.gradient + '"></div>' +
          '<div class="post-actions">' +
            '<button data-like="' + p.id + '">♥<small>' + App.formatNumber(p.likes) + '</small></button>' +
            '<button data-comment="' + p.id + '">💬<small>' + p.comments + '</small></button>' +
            '<button data-share="' + p.id + '">↗<small>' + p.shares + '</small></button>' +
          '</div>' +
          '<div class="post-info">' +
            '<div class="post-user">@' + p.username + '</div>' +
            '<div class="post-title">' + p.title + '</div>' +
            '<div class="post-desc">' + p.desc + '</div>' +
            '<span class="post-tag ' + (p.type === 'need' ? 'need' : '') + '">' + (p.type === 'need' ? 'Necesito' : 'Ofrezco') + '</span>' +
            '<div class="post-loc">📍 ' + p.city + ', ' + p.country + ' · ' + p.category + '</div>' +
          '</div>';
        post.querySelector('[data-like]').addEventListener('click', function (e) {
          e.stopPropagation();
          var small = e.currentTarget.querySelector('small');
          p.likes++;
          small.textContent = App.formatNumber(p.likes);
        });
        post.querySelector('[data-comment]').addEventListener('click', function (e) {
          e.stopPropagation(); App.showToast('Comentarios (demo)');
        });
        post.querySelector('[data-share]').addEventListener('click', function (e) {
          e.stopPropagation(); p.shares++; e.currentTarget.querySelector('small').textContent = App.formatNumber(p.shares); App.showToast('Enlace copiado');
        });
        post.querySelector('.post-user').addEventListener('click', function () {
          if (window.Profile && window.Profile.openOther) { window.Profile.openOther(p); }
        });
        container.appendChild(post);
      })(list[i]);
    }
  }

  window.Feed = {
    init: function () {
      // Cargar del servidor si hay, sino datos de ejemplo
      if (window.Api && window.Api.listPosts) {
        window.Api.listPosts({}).then(function (posts) {
          render(posts && posts.length ? posts : SAMPLE);
        }).catch(function () { render(SAMPLE); });
      } else { render(SAMPLE); }

      // Filtros ciudad/país/mundo
      var chips = document.querySelectorAll('.chip[data-filter]');
      for (var i = 0; i < chips.length; i++) {
        chips[i].addEventListener('click', function (e) {
          var c = e.currentTarget;
          var sibs = c.parentElement.querySelectorAll('.chip');
          for (var j = 0; j < sibs.length; j++) { sibs[j].classList.remove('active'); }
          c.classList.add('active');
          App.state.filter = c.getAttribute('data-filter');
        });
      }

      // Búsqueda
      var search = document.getElementById('feed-search-input');
      if (search) {
        search.addEventListener('input', function () {
          var q = search.value.toLowerCase();
          var filtered = SAMPLE.filter(function (p) {
            return p.title.toLowerCase().indexOf(q) >= 0 || p.desc.toLowerCase().indexOf(q) >= 0 || p.category.toLowerCase().indexOf(q) >= 0;
          });
          render(filtered.length ? filtered : SAMPLE);
        });
      }

      // Saludo de Dimon al entrar al feed (voz si está disponible)
      var greeted = false;
      var obs = new MutationObserver(function () {
        var s = document.getElementById('screen-feed');
        if (s && s.classList.contains('active') && !greeted) {
          greeted = true;
          var hi = 'Bienvenido a Dimon Connet. Deslizá para ver servicios.';
          if ('speechSynthesis' in window) {
            try {
              var u = new SpeechSynthesisUtterance(hi);
              u.lang = 'es-ES'; u.volume = 0.8;
              window.speechSynthesis.speak(u);
              document.body.addEventListener('click', function once() {
                try { window.speechSynthesis.cancel(); } catch (e) {}
                document.body.removeEventListener('click', once);
              });
            } catch (e) {}
          }
        }
      });
      obs.observe(document.body, { attributes: true, subtree: true, attributeFilter: ['class'] });
    },
    render: render
  };
})();

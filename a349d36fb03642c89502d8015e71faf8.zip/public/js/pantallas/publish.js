'use strict';
// Crear publicación: valida bloqueo de teléfono/correo/enlace en cliente y servidor.
(function () {
  var pubType = 'offer';
  var pubDuration = 14;

  window.Publish = {
    init: function () {
      // Llenar select de categorías
      var sel = document.getElementById('pub-category');
      if (sel && window.Categories) {
        sel.innerHTML = '';
        var cats = window.Categories.data;
        for (var i = 0; i < cats.length; i++) {
          var o = document.createElement('option');
          o.value = cats[i].name; o.textContent = cats[i].name;
          sel.appendChild(o);
        }
      }

      // Toggle Ofrezco/Necesito
      var segs = document.querySelectorAll('#screen-publish .seg[data-type]');
      for (var j = 0; j < segs.length; j++) {
        segs[j].addEventListener('click', function (e) {
          var s = e.currentTarget;
          var sibs = s.parentElement.querySelectorAll('.seg');
          for (var k = 0; k < sibs.length; k++) { sibs[k].classList.remove('active'); }
          s.classList.add('active');
          pubType = s.getAttribute('data-type');
        });
      }
      // Duración
      var durs = document.querySelectorAll('#screen-publish .seg[data-duration]');
      for (var d = 0; d < durs.length; d++) {
        durs[d].addEventListener('click', function (e) {
          var s = e.currentTarget;
          var sibs = s.parentElement.querySelectorAll('.seg');
          for (var k2 = 0; k2 < sibs.length; k2++) { sibs[k2].classList.remove('active'); }
          s.classList.add('active');
          pubDuration = Number(s.getAttribute('data-duration'));
          var note = document.getElementById('pub-expiry-note');
          if (note) {
            var exp = new Date(Date.now() + pubDuration * 86400000);
            note.textContent = 'Vence el ' + exp.toLocaleDateString() + (pubDuration === 14 ? ' (se borra del muro)' : ' (rota en el perfil)');
          }
        });
      }

      // Previsualizar media
      var media = document.getElementById('pub-media');
      if (media) { media.addEventListener('change', function (e) {
        var prev = document.getElementById('pub-media-preview');
        if (prev && e.target.files && e.target.files[0]) { prev.textContent = '📷'; }
      }); }

      // Enviar
      var btn = document.getElementById('btn-publish-submit');
      if (btn) { btn.addEventListener('click', async function () {
        var title = document.getElementById('pub-title').value.trim();
        var desc = document.getElementById('pub-desc').value.trim();
        if (!title) { window.App.showToast('Escribí un título'); return; }
        // Bloqueo de datos de contacto (cliente)
        if (window.App.blockContactInfo(title) || window.App.blockContactInfo(desc)) {
          window.App.showToast(window.App.t('publish.blocked'));
          return;
        }
        // Límite 15 activas
        var myPosts = [];
        try { myPosts = JSON.parse(localStorage.getItem('dimon_my_posts') || '[]'); } catch (e) {}
        if (myPosts.length >= 15) { window.App.showToast(window.App.t('publish.limit')); return; }

        var cat = document.getElementById('pub-category').value;
        var post = { title: title, desc: desc, type: pubType, category: cat, duration: pubDuration, country: window.App.state.country, city: 'Mi ciudad' };
        var r = await window.Api.createPost(post);
        if (r && r.ok) {
          myPosts.push(post);
          try { localStorage.setItem('dimon_my_posts', JSON.stringify(myPosts)); } catch (e) {}
          window.App.showToast('¡Publicación creada!');
          document.getElementById('pub-title').value = '';
          document.getElementById('pub-desc').value = '';
          window.App.switchScreen('screen-feed');
          if (window.Feed && window.Feed.render) { window.Feed.render(); }
        } else {
          window.App.showToast(r && r.error === 'contact_info_not_allowed' ? window.App.t('publish.blocked') : 'No se pudo publicar');
        }
      }); }
    }
  };
})();

'use strict';
// En vivo: video simulado, comentarios en vivo, contador de espectadores, transcripción.
(function () {
  var COMMENTS = [
    { u: 'ana_lopez', t: '¡Qué buen servicio! 👏' },
    { u: 'pablo_g', t: '¿Cuánto cuesta por hora?' },
    { u: 'maria_23', t: 'De dónde sos?' },
    { u: 'tech_fan', t: 'Me interesa, te escribo al chat' },
    { u: 'lucia_ok', t: 'Recomendado, lo contraté antes' },
    { u: 'juan_perez', t: '¿Atienden los fines de semana?' }
  ];
  var ci = 0;
  var timer = null;

  window.Live = {
    init: function () {
      var transBtn = document.getElementById('btn-transcribe');
      if (transBtn) { transBtn.addEventListener('click', function () {
        var t = document.getElementById('live-transcript');
        if (t) {
          t.classList.remove('hidden');
          t.textContent = 'Transcripción (simulada): "Hola a todos, hoy les muestro cómo trabajo. Los precios son por hora y acepto las tres pasarelas de pago. Cualquier duda me escriben por el chat interno."';
        }
      }); }

      var obs = new MutationObserver(function () {
        var s = document.getElementById('screen-live');
        if (s && s.classList.contains('active') && !timer) {
          var box = document.getElementById('live-comments');
          var viewers = document.getElementById('live-viewers');
          var v = 128;
          timer = setInterval(function () {
            if (!box) { return; }
            var c = COMMENTS[ci % COMMENTS.length];
            ci++;
            var div = document.createElement('div');
            div.innerHTML = '<b>@' + c.u + '</b> ' + c.t;
            box.appendChild(div);
            box.scrollTop = box.scrollHeight;
            v += Math.floor(Math.random() * 5) - 1;
            if (viewers) { viewers.textContent = v; }
            if (box.children.length > 30) { box.removeChild(box.firstChild); }
          }, 2200);
        } else if (s && !s.classList.contains('active') && timer) {
          clearInterval(timer); timer = null;
        }
      });
      obs.observe(document.body, { attributes: true, subtree: true, attributeFilter: ['class'] });
    }
  };
})();

'use strict';
// Pagos: 3 pasarelas. Dimon detecta el país y muestra solo las disponibles.
// Si hay PAYPAL_CLIENT_ID configurado → carga el SDK de PayPal y muestra botones reales.
// Si no → modo simulado explicativo.
(function () {
  var MP_COUNTRIES = ['AR','BO','BR','CL','CO','CR','DO','EC','GT','HN','MX','NI','PA','PE','PY','SV','UY','VE'];
  var STRIPE_COUNTRIES = ['US','GB','CA','AU','NZ','IE','FR','DE','IT','ES','PT','NL','BE','AT','CH','SE','NO','DK','FI','PL','CZ','GR','SG','HK','JP'];
  var PRICES = { '1': 2.99, '2': 1.99, '3': 4.49 };
  var paypalLoaded = false;
  var paypalLoading = false;

  function getConfig() {
    return (window.App && window.App.state && window.App.state.config) || { payments: {} };
  }
  function available(countryCode, config) {
    config = config || getConfig();
    var list = [{ id: 'paypal', name: 'PayPal', available: true, configured: !!config.paypalClientId }];
    if (MP_COUNTRIES.indexOf(countryCode) >= 0) {
      list.push({ id: 'mercadopago', name: 'Mercado Pago', available: true, configured: !!config.payments.mercadopago });
    }
    if (STRIPE_COUNTRIES.indexOf(countryCode) >= 0) {
      list.push({ id: 'stripe', name: 'Stripe', available: true, configured: !!config.payments.stripe });
    }
    return list;
  }

  function loadPaypalSDK(clientId, mode) {
    return new Promise(function (resolve, reject) {
      if (window.paypal) { resolve(window.paypal); return; }
      if (paypalLoading) {
        var iv = setInterval(function () { if (window.paypal) { clearInterval(iv); resolve(window.paypal); } }, 200);
        setTimeout(function () { clearInterval(iv); if (!window.paypal) reject(new Error('timeout')); }, 15000);
        return;
      }
      paypalLoading = true;
      var s = document.createElement('script');
      s.src = 'https://www.paypal.com/sdk/js?client-id=' + encodeURIComponent(clientId) + '&currency=USD&intent=capture';
      s.onload = function () { paypalLoaded = true; resolve(window.paypal); };
      s.onerror = function () { paypalLoading = false; reject(new Error('paypal_sdk_error')); };
      document.head.appendChild(s);
    });
  }

  function activateFeatured(plan) {
    try {
      var feats = JSON.parse(localStorage.getItem('dimon_featured') || '[]');
      feats.push({ plan: plan, at: Date.now(), expires: Date.now() + 86400000 });
      localStorage.setItem('dimon_featured', JSON.stringify(feats));
    } catch (e) {}
    if (window.App) { window.App.showToast('Pago confirmado — destacado activado'); }
  }

  window.Payments = {
    available: available,
    currentPlan: null,
    init: function () {
      var buyBtns = document.querySelectorAll('[data-buy]');
      for (var i = 0; i < buyBtns.length; i++) {
        buyBtns[i].addEventListener('click', function (e) {
          Payments.openCheckout(e.currentTarget.getAttribute('data-buy'));
        });
      }
      var confirm = document.getElementById('btn-paypal-confirm');
      if (confirm) { confirm.addEventListener('click', Payments.confirmSimulated); }
    },
    openCheckout: function (plan) {
      Payments.currentPlan = plan;
      var amount = document.getElementById('paypal-amount');
      if (amount) { amount.textContent = 'US$ ' + (PRICES[plan] || 0).toFixed(2); }
      var config = getConfig();
      var country = (window.App && window.App.state && window.App.state.country) || 'UY';
      var opts = available(country, config);
      var names = [];
      for (var i = 0; i < opts.length; i++) {
        names.push(opts[i].name + (opts[i].configured ? '' : ' (próximamente)'));
      }
      var modal = document.getElementById('modal-paypal');
      var simBtn = document.getElementById('btn-paypal-confirm');
      var container = document.getElementById('paypal-button-container');
      if (!modal) { return; }
      var note = modal.querySelector('.muted.small');
      if (note) { note.textContent = 'Pasarelas disponibles en tu país: ' + names.join(', '); }
      modal.classList.remove('hidden');

      // Limpiar contenedor de botones anteriores
      if (container) { container.innerHTML = ''; }

      if (config.paypalClientId && window.fetch) {
        // Modo real: cargar SDK de PayPal y renderizar botones
        if (simBtn) { simBtn.style.display = 'none'; }
        loadPaypalSDK(config.paypalClientId, config.paypalMode || 'sandbox').then(function (paypal) {
          if (!container || !paypal.Buttons) {
            if (simBtn) { simBtn.style.display = ''; }
            return;
          }
          paypal.Buttons({
            style: { layout: 'vertical', shape: 'pill', label: 'pay' },
            createOrder: function (data, actions) {
              return actions.order.create({
                purchase_units: [{ amount: { value: (PRICES[plan] || 0).toFixed(2) } }]
              });
            },
            onApprove: function (data, actions) {
              return actions.order.capture().then(function (details) {
                if (modal) { modal.classList.add('hidden'); }
                activateFeatured(plan);
              });
            },
            onError: function (err) {
              if (window.App) { window.App.showToast('Error en PayPal: intenta nuevamente'); }
            }
          }).render('#paypal-button-container');
        }).catch(function () {
          if (simBtn) { simBtn.style.display = ''; }
          if (note) { note.textContent = 'No se pudo cargar PayPal. Usá el botón de confirmación (modo demo).'; }
        });
      } else {
        // Modo simulado
        if (simBtn) { simBtn.style.display = ''; }
        if (note) { note.textContent = note.textContent + ' — Modo demo: no se procesa un pago real.'; }
      }
    },
    confirmSimulated: function () {
      var modal = document.getElementById('modal-paypal');
      if (modal) { modal.classList.add('hidden'); }
      activateFeatured(Payments.currentPlan);
      if (window.App) { window.App.showToast('Pago recibido (demo) — destacado activado'); }
    }
  };
})();

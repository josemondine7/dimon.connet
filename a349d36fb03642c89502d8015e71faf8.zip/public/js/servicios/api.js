'use strict';
// Cliente de API. Si el servidor no está disponible (ej: file://), cae a modo simulado.
(function () {
  var TOKEN_KEY = 'dimon_token';
  function getToken() { try { return localStorage.getItem(TOKEN_KEY) || null; } catch (e) { return null; } }
  function setToken(t) { try { if (t) { localStorage.setItem(TOKEN_KEY, t); } else { localStorage.removeItem(TOKEN_KEY); } } catch (e) {} }

  async function req(path, options) {
    options = options || {};
    var headers = options.headers || {};
    headers['Content-Type'] = 'application/json';
    var tok = getToken();
    if (tok) { headers['Authorization'] = 'Bearer ' + tok; }
    try {
      var resp = await fetch(path, {
        method: options.method || 'GET',
        headers: headers,
        body: options.body ? JSON.stringify(options.body) : undefined
      });
      var data = await resp.json().catch(function () { return {}; });
      return { ok: resp.ok, status: resp.status, data: data };
    } catch (e) {
      return { ok: false, offline: true, data: null };
    }
  }

  window.Api = {
    getToken: getToken,
    setToken: setToken,
    getConfig: async function () {
      var r = await req('/api/config');
      return r.ok ? r.data : null;
    },
    register: async function (username, email, password) {
      var r = await req('/api/register', { method: 'POST', body: { username: username, email: email, password: password } });
      if (r.ok && r.data && r.data.token) { setToken(r.data.token); return r.data; }
      if (r.offline) {
        // Modo simulado
        setToken('sim-' + Date.now());
        return { ok: true, token: 'sim', user: { username: username, email: email }, simulated: true };
      }
      return { ok: false, error: (r.data && r.data.error) || 'error' };
    },
    login: async function (username, password) {
      var r = await req('/api/login', { method: 'POST', body: { username: username, password: password } });
      if (r.ok && r.data && r.data.token) { setToken(r.data.token); return r.data; }
      if (r.offline) { setToken('sim-' + Date.now()); return { ok: true, token: 'sim', user: { username: username }, simulated: true }; }
      return { ok: false, error: (r.data && r.data.error) || 'bad_credentials' };
    },
    me: async function () {
      var r = await req('/api/me');
      return r.ok ? r.data : null;
    },
    listPosts: async function (filter) {
      var q = filter ? '?category=' + encodeURIComponent(filter.category || '') + '&country=' + encodeURIComponent(filter.country || '') : '';
      var r = await req('/api/posts' + q);
      if (r.ok && r.data) { return r.data.posts || []; }
      return [];
    },
    createPost: async function (post) {
      var r = await req('/api/posts', { method: 'POST', body: post });
      if (r.ok) { return r.data; }
      if (r.offline) { return { ok: true, simulated: true, post: post }; }
      return { ok: false, error: (r.data && r.data.error) || 'error' };
    },
    adminLogin: async function (username, password) {
      var r = await req('/api/admin/login', { method: 'POST', body: { username: username, password: password } });
      if (r.ok && r.data && r.data.token) { try { localStorage.setItem('dimon_admin_token', r.data.token); } catch (e) {} return r.data; }
      return { ok: false, error: (r.data && r.data.error) || 'bad_admin_credentials' };
    },
    adminReq: async function (path) {
      var tok = null;
      try { tok = localStorage.getItem('dimon_admin_token'); } catch (e) {}
      try {
        var resp = await fetch(path, { headers: { 'Authorization': 'Bearer ' + (tok || '') } });
        var data = await resp.json().catch(function () { return {}; });
        return { ok: resp.ok, data: data };
      } catch (e) { return { ok: false, offline: true, data: null }; }
    },
    dimonChat: async function (messages) {
      var r = await req('/api/dimon-chat', { method: 'POST', body: { messages: messages } });
      if (r.ok && r.data) { return r.data; }
      return { simulated: true, reply: null };
    }
  };
})();

# Dimon Connet — Servicios Autónomos

Plataforma web móvil (SPA, mobile-first) que conecta personas que ofrecen y necesitan servicios. Entrada sin barreras: tocás "Iniciar" y ya navegás el muro. El registro solo se pide cuando querés publicar, contratar u ofrecer.

**Marca:** Dimon Connet (una sola 'c' en Connet) · Subtítulo: *Servicios Autónomos* · Asistente: *Dimon IA*.
**Contacto oficial:** dimon.connet@gmail.com

> ⚠️ **ADVERTENCIA MUY IMPORTANTE — LEER ANTES DE COMPARTIR**
> - Este proyecto se entrega con un archivo `.env` que contiene **claves reales de PayPal (modo live), contraseña de administrador y secreto JWT**. **NO compartas el zip ni el `.env` con nadie.**
> - **NUNCA hagas `git add .env` ni `git commit .env`.** El `.gitignore` ya lo excluye. Verificá antes de pushear a GitHub.
> - **`ADMIN_PASSWORD=josemondine7` es una contraseña DÉBIL.** Cambiála por una fuerte en producción (y también `JWT_SECRET`).
> - Las claves de PayPal son de la cuenta actual; cuando pases oficialmente a producción **rotá las credenciales** en el dashboard de PayPal.
> - La carpeta `data/` contiene `actas.json` con **datos personales (cédulas)**. **NUNCA la subas a GitHub** (está en `.gitignore`). Las actas son documentos privados del dueño, visibles solo dentro de Dimon General con acceso de administrador. Para validez legal real requieren **escritura pública o testamento ante escribano** — el archivo digital es solo respaldo interno.

## Decisiones de negocio aplicadas (log de inconsistencias resueltas)

1. **Comisión: 15% de cada lado (30% total para la plataforma).** El manual decía 15%, un `.env` intermedio decía 10%, y un texto legal decía 3%. El usuario confirmó finalmente **15%/15%**. Es configurable vía `FEE_HIRER_PERCENT` y `FEE_WORKER_PERCENT` en `.env`; el cliente lo muestra dinámicamente (no hay porcentajes hardcodeados en la UI).
2. **Cuota Comercios y Empresas: US$ 45/mes** (resumen de cobros del 18 de octubre; el manual §7 decía US$ 50 — no se usa).
3. **Proyectos:** comisión 15% de cada lado. En la pantalla Proyectos se menciona que antes se manejaba US$ 30 por contacto como alternativa histórica.
4. **Marca:** "Dimon Connet" (una sola 'c') en toda la UI, como el logo SVG y las imágenes de referencia. La URL de Render (`dimon-connect.onrender.com`) es solo una URL, no afecta la marca. `PLATFORM_NAME` es configurable en `.env`.

## Stack

- Backend: Node.js + Express ^4.18 + bcryptjs ^2.4 + jsonwebtoken ^9.0.
- Almacenamiento v1: archivos JSON en `data/` con capa de datos única (`server/db.js`), preparada para swapear a MongoDB cambiando solo esa capa.
- Frontend: HTML + CSS + JavaScript vanilla (sin librerías externas ni CDN).
- Pagos: 3 pasarelas (PayPal mundial, Mercado Pago en América Latina, Stripe en UE/EE.UU.) — Dimon detecta el país y muestra solo las disponibles. Sin claves configuradas → UI simulada.
- IA: Dimon IA con proxy a Groq (`/api/dimon-chat`); sin `GROQ_API_KEY` usa respuestas simuladas. La clave nunca va al cliente.

## Estructura

```
dimon-connet/
├── package.json · server.js · server/db.js
├── .env (real, NO commitear) · .env.example · .gitignore · README.md
├── data/ (actas.json, users.json, posts.json — NO commitear)
├── dimon-general/ (documentación de la zona privada)
└── public/
    ├── index.html
    ├── css/styles.css
    └── js/
        ├── core/ (app.js, countries.js, translations.js, terms.js)
        ├── servicios/ (api.js, payments.js)
        ├── colaboradores/ (dimonIA.js — 11 áreas conceptuales)
        └── pantallas/ (auth, profile, feed, publish, categories, live, dimonGeneral)
```

## Correr localmente

```bash
npm install
npm start   # usa PORT de .env (3001) o el que asigne el sistema
# abre http://localhost:3001
```

## Subir a GitHub

```bash
cd dimon-connet
git init
git add .          # verificá que .env y data/ NO se agreguen (.gitignore los excluye)
git status         # confirmá que no aparece .env ni data/
git commit -m "Dimon Connet — versión inicial"
# creá el repo vacío en GitHub y:
git remote add origin https://github.com/TU_USUARIO/dimon-connet.git
git branch -M main && git push -u origin main
```

## Desplegar en Render

1. **New > Web Service** → conectá el repo.
2. Build: `npm install` · Start: `npm start`.
3. Variables de entorno (Environment):
   - `PAYPAL_CLIENT_ID`, `PAYPAL_CLIENT_SECRET`, `PAYPAL_MODE=live`
   - `MERCADOPAGO_ACCESS_TOKEN` (opcional)
   - `STRIPE_SECRET_KEY` (opcional)
   - `GROQ_API_KEY` (opcional, para IA real)
   - `JWT_SECRET` (una clave larga y aleatoria), `JWT_EXPIRES_IN=7d`
   - `FEE_HIRER_PERCENT=15`, `FEE_WORKER_PERCENT=15`
   - `ADMIN_USER`, `ADMIN_PASSWORD` (fuerte), `ADMIN_NAME`, `ADMIN_EMAIL`, `ADMIN_DOC`
   - `PLATFORM_URL`, `PLATFORM_NAME=Dimon Connet`

### Cómo obtener cada clave

- **PayPal:** developer.paypal.com → Apps & Credentials → Client ID + Secret (sandbox para probar; live para producción). Cambiá `PAYPAL_MODE` a `live` solo cuando las claves sean de live.
- **Mercado Pago:** mercadopago.com/developers → Tus integraciones → Access Token.
- **Stripe:** dashboard.stripe.com/apikeys → Secret Key (empieza con `sk_`).
- **Groq:** console.groq.com → API Keys.

### Cómo conectar MongoDB (cuando tengas una URI real)

1. Obtené una URI real en MongoDB Atlas con formato: `mongodb+srv://usuario:contraseña@cluster0.xxxxx.mongodb.net/dimon` (la URI que incluía un token de GitHub como contraseña no es válida).
2. Instalá el driver: `npm install mongodb`.
3. Reemplazá las funciones de `server/db.js` por llamadas a MongoDB (findUser, createUser, listPosts, createPost, createDeal, listDeals, listSessions, addSession) — el resto del servidor y el cliente no cambian.
4. Agregá `MONGODB_URI` a las variables de entorno.

## Dimon General (zona privada del dueño)

Acceso oculto (no está en el menú de usuarios comunes): 5 toques en el logo del login, o `/admin` (redirige a `/#admin`), o el punto diminuto al pie de "Información del creador". Protegido por usuario/contraseña de admin con JWT. Incluye: analítica, repositorio, tareas editables, versiones, ingresos, gestión, seguridad (sesiones), y **Actas y Documentos Legales** (visibles solo con token de admin válido, servidas desde `data/actas.json`).

## Seguridad

- Contraseñas de usuarios y admin con bcryptjs; sesiones con JWT.
- `ADMIN_DOC` (cédula) y las actas solo se devuelven en endpoints de admin autenticados. Nunca en `public/` ni en código cliente.
- Detector automático bloquea teléfonos, correos y enlaces en publicaciones (cliente + servidor).
- La plataforma no maneja el dinero del servicio entre las personas: solo intermedia.

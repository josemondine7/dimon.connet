'use strict';

// Dimon Connet — Servicios Autónomos
// Backend: Express + bcryptjs + jsonwebtoken + capa de datos JSON (server/db.js).
// Los secretos vienen de variables de entorno (.env local o Render).

const express = require('express');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('./server/db');

const app = express();
// PORT se define más abajo, DESPUÉS de cargar .env (ver línea siguiente a loadEnv)

// --- Carga mínima de .env (sin dependencia extra) para desarrollo local ---
(function loadEnv() {
  const envPath = path.join(__dirname, '.env');
  if (!fs.existsSync(envPath)) { return; }
  const lines = fs.readFileSync(envPath, 'utf8').split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line || line.startsWith('#')) { continue; }
    const eq = line.indexOf('=');
    if (eq < 0) { continue; }
    const key = line.slice(0, eq).trim();
    const val = line.slice(eq + 1).trim();
    if (!(key in process.env)) { process.env[key] = val; }
  }
})();

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'dimon-dev-insecure-change-me';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '30d';
const FEES = {
  hirer: Number(process.env.FEE_HIRER_PERCENT) || 10,
  worker: Number(process.env.FEE_WORKER_PERCENT) || 10
};

// Hash de la contraseña de admin EN MEMORIA al arrancar (nunca se guarda en disco).
const ADMIN_USER = (process.env.ADMIN_USER || 'admin').toLowerCase();
let ADMIN_HASH = null;
if (process.env.ADMIN_PASSWORD) {
  ADMIN_HASH = bcrypt.hashSync(process.env.ADMIN_PASSWORD, 10);
}

app.use(express.json({ limit: '256kb' }));
app.use(express.static(path.join(__dirname, 'public')));

// --- Middlewares ---
function contactBlocked(text) {
  if (!text) { return false; }
  const re = /([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})|(\+?\d[\d\s\-().]{7,}\d)|(https?:\/\/)|(www\.)|(\.(com|net|org|io|uy|ar|br|es|cl|co|pe|ve|mx)\b)/i;
  return re.test(String(text));
}
function authRequired(req, res, next) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (!token) { return res.status(401).json({ ok: false, error: 'no_token' }); }
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch (e) { return res.status(401).json({ ok: false, error: 'bad_token' }); }
}
function adminRequired(req, res, next) {
  authRequired(req, res, function () {
    if (req.user && req.user.role === 'admin') { next(); }
    else { res.status(403).json({ ok: false, error: 'not_admin' }); }
  });
}
function publicUser(u) {
  if (!u) { return null; }
  return { id: u.id, username: u.username, email: u.email, createdAt: u.createdAt };
}

// --- Configuración pública (sin secretos) ---
app.get('/api/config', (req, res) => {
  res.json({
    paypalMode: process.env.PAYPAL_MODE || 'sandbox',
    paypalClientId: process.env.PAYPAL_CLIENT_ID || '',
    payments: {
      paypal: !!process.env.PAYPAL_CLIENT_ID,
      mercadopago: !!process.env.MERCADOPAGO_ACCESS_TOKEN,
      stripe: !!process.env.STRIPE_SECRET_KEY
    },
    groqEnabled: !!process.env.GROQ_API_KEY,
    appName: process.env.PLATFORM_NAME || 'Dimon Connet',
    subtitle: 'Servicios Autónomos',
    platformUrl: process.env.PLATFORM_URL || '',
    fees: { hirer: FEES.hirer, worker: FEES.worker, total: FEES.hirer + FEES.worker }
  });
});

// --- Registro y login de usuarios ---
app.post('/api/register', (req, res) => {
  const b = req.body || {};
  const username = String(b.username || '').trim();
  const email = String(b.email || '').trim();
  const password = String(b.password || '');
  if (!username || !password || password.length < 4) {
    return res.status(400).json({ ok: false, error: 'invalid_data' });
  }
  if (db.findUser(username) || (email && db.findUser(email))) {
    return res.status(409).json({ ok: false, error: 'user_exists' });
  }
  const hash = bcrypt.hashSync(password, 10);
  const user = db.createUser({ username: username, email: email, passwordHash: hash });
  const token = jwt.sign({ id: user.id, username: user.username, role: 'user' }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
  db.addSession({ userId: user.id, type: 'register', ua: String(req.headers['user-agent'] || '').slice(0, 80) });
  res.json({ ok: true, token: token, user: publicUser(user) });
});

app.post('/api/login', (req, res) => {
  const b = req.body || {};
  const username = String(b.username || '').trim();
  const password = String(b.password || '');
  const user = db.findUser(username);
  if (!user || !bcrypt.compareSync(password, user.passwordHash)) {
    return res.status(401).json({ ok: false, error: 'bad_credentials' });
  }
  const token = jwt.sign({ id: user.id, username: user.username, role: 'user' }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
  db.addSession({ userId: user.id, type: 'login', ua: String(req.headers['user-agent'] || '').slice(0, 80) });
  res.json({ ok: true, token: token, user: publicUser(user) });
});

app.get('/api/me', authRequired, (req, res) => {
  const user = db.findUserById(req.user.id);
  res.json({ ok: true, user: publicUser(user) });
});

// --- Publicaciones ---
const SAMPLE_POSTS = [
  { id: 101, username: 'caro_fit', title: 'Clases de yoga personalizadas', desc: 'Sesiones online y a domicilio. Principiantes bienvenidos.', type: 'offer', category: 'Bienestar y salud', city: 'Montevideo', country: 'UY', likes: 124, comments: 18, shares: 5, gradient: 'linear-gradient(160deg,#0052cc,#00aaff)' },
  { id: 102, username: 'techleo', title: 'Reparación de celulares y tablets', desc: 'Cambio de pantalla y batería en el día. Garantía.', type: 'offer', category: 'Servicios técnicos y reparaciones', city: 'São Paulo', country: 'BR', likes: 342, comments: 41, shares: 22, gradient: 'linear-gradient(160deg,#0a2463,#3e92cc)' },
  { id: 103, username: 'maria_limpieza', title: 'Limpieza profunda de casas', desc: 'Necesito equipo de limpieza para fin de semana.', type: 'need', category: 'Servicios del hogar', city: 'Buenos Aires', country: 'AR', likes: 56, comments: 12, shares: 3, gradient: 'linear-gradient(160deg,#2d6a4f,#95d5b2)' },
  { id: 104, username: 'diseño_ana', title: 'Diseño de logotipos y marcas', desc: 'Identidad visual completa para tu emprendimiento.', type: 'offer', category: 'Creativos y diseño', city: 'Lima', country: 'PE', likes: 289, comments: 33, shares: 17, gradient: 'linear-gradient(160deg,#6a0572,#ab83a1)' },
  { id: 105, username: 'chef_rodrigo', title: 'Catering para eventos', desc: 'Menú casero para 20 personas. Presupuesto sin cargo.', type: 'offer', category: 'Servicios generales', city: 'Santiago', country: 'CL', likes: 178, comments: 25, shares: 9, gradient: 'linear-gradient(160deg,#b5651d,#f4a261)' },
  { id: 106, username: 'estudio_juridico', title: 'Asesoría legal laboral', desc: 'Consulta inicial gratuita por la plataforma.', type: 'offer', category: 'Servicios profesionales', city: 'Madrid', country: 'ES', likes: 95, comments: 14, shares: 6, gradient: 'linear-gradient(160deg,#1d3557,#457b9d)' }
];

app.get('/api/posts', (req, res) => {
  let posts = db.listPosts({ category: req.query.category, country: req.query.country });
  if (!posts || posts.length === 0) { posts = SAMPLE_POSTS; }
  res.json({ ok: true, posts: posts });
});

app.post('/api/posts', authRequired, (req, res) => {
  const b = req.body || {};
  const title = String(b.title || '');
  const desc = String(b.desc || '');
  if (!title) { return res.status(400).json({ ok: false, error: 'no_title' }); }
  if (contactBlocked(title) || contactBlocked(desc)) {
    return res.status(400).json({ ok: false, error: 'contact_info_not_allowed' });
  }
  const post = db.createPost({
    userId: req.user.id, username: req.user.username,
    title: title, desc: desc, type: b.type || 'offer',
    category: b.category || 'Otros servicios', city: b.city || '', country: b.country || '',
    duration: b.duration || 14, likes: 0, comments: 0, shares: 0,
    gradient: 'linear-gradient(160deg,#0052cc,#00aaff)'
  });
  res.json({ ok: true, post: post });
});

// --- Tratos ---
app.post('/api/deals', authRequired, (req, res) => {
  const b = req.body || {};
  const deal = db.createDeal({ userId: req.user.id, amount: Number(b.amount) || 0, description: String(b.description || ''), status: 'pending' });
  res.json({ ok: true, deal: deal });
});

// --- Dimon General (admin) ---
// Legacy: contraseña única de creador (CREATOR_PASSWORD). Se mantiene por compatibilidad.
app.post('/api/creator-login', (req, res) => {
  const entered = typeof (req.body || {}).password === 'string' ? req.body.password : '';
  const hasEnv = !!process.env.CREATOR_PASSWORD;
  const expected = process.env.CREATOR_PASSWORD || 'dimon2026';
  if (entered === expected) { return res.json({ ok: true, mustChange: !hasEnv }); }
  return res.status(401).json({ ok: false, mustChange: !hasEnv });
});

app.post('/api/admin/login', (req, res) => {
  const b = req.body || {};
  const username = String(b.username || '').trim().toLowerCase();
  const password = String(b.password || '');
  if (!ADMIN_HASH || username !== ADMIN_USER || !bcrypt.compareSync(password, ADMIN_HASH)) {
    return res.status(401).json({ ok: false, error: 'bad_admin_credentials' });
  }
  const token = jwt.sign({ id: 0, username: process.env.ADMIN_USER || 'admin', role: 'admin' }, JWT_SECRET, { expiresIn: '12h' });
  db.addSession({ userId: 0, type: 'admin_login', ua: String(req.headers['user-agent'] || '').slice(0, 80) });
  res.json({ ok: true, token: token, role: 'admin' });
});

app.get('/api/admin/stats', adminRequired, (req, res) => {
  const users = db.listUsers();
  const posts = db.listPosts({});
  const deals = db.listDeals();
  res.json({
    ok: true,
    users: users.length,
    posts: posts.length,
    deals: deals.length,
    sessions: db.listSessions().length,
    featured: 3
  });
});

app.get('/api/admin/sessions', adminRequired, (req, res) => {
  res.json({ ok: true, sessions: db.listSessions().slice(-20).reverse() });
});

// ADMIN_DOC (cédula) se devuelve SOLO acá, con token de admin válido. Nunca al cliente común.
app.get('/api/admin/info', adminRequired, (req, res) => {
  res.json({
    ok: true,
    name: process.env.ADMIN_NAME || '',
    email: process.env.ADMIN_EMAIL || '',
    doc: process.env.ADMIN_DOC || ''
  });
});

// Actas y documentos legales: solo con JWT de admin válido. Están en data/actas.json (gitignored).
app.get('/api/admin/actas', adminRequired, (req, res) => {
  try {
    const raw = fs.readFileSync(path.join(__dirname, 'data', 'actas.json'), 'utf8');
    res.json({ ok: true, actas: JSON.parse(raw).actas || [] });
  } catch (e) {
    res.json({ ok: true, actas: [] });
  }
});

// --- Proxy de Dimon IA (Groq) ---
app.post('/api/dimon-chat', async (req, res) => {
  const messages = Array.isArray((req.body || {}).messages) ? req.body.messages : [];
  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey) { return res.json({ simulated: true, reply: null }); }
  try {
    const resp = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + apiKey },
      body: JSON.stringify({ model: 'llama-3.1-8b-instant', messages: messages.slice(-10), max_tokens: 400, temperature: 0.6 })
    });
    if (!resp.ok) { return res.json({ simulated: true, reply: null, error: 'upstream_' + resp.status }); }
    const data = await resp.json();
    const reply = data && data.choices && data.choices[0] && data.choices[0].message ? data.choices[0].message.content : null;
    return res.json({ simulated: false, reply: reply });
  } catch (err) {
    return res.json({ simulated: true, reply: null, error: 'network' });
  }
});

// /admin redirige a la zona privada dentro del SPA (Dimon General).
app.get('/admin', (req, res) => { res.redirect('/#admin'); });

// Fallback SPA: rutas no-API y no-/admin devuelven index.html.
app.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) { return res.status(404).json({ ok: false, error: 'not_found' }); }
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => { console.log('Dimon Connet escuchando en el puerto', PORT); });
